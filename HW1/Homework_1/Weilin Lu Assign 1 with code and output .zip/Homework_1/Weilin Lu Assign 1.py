import csv
salaries2020 = []
salaries2021 = []
salaries2022 = []
##salary for SE title
salaries_SE_SDS = []    #Staff Data Scientist
salaries_SE_RS = []     #Research Scientist
salaries_SE_PDS = []    #Principal Data Scientist
salaries_SE_PDE = []    #Principal Data Engineer
salaries_SE_PDA = []    #Prtincipal Data Analyst
salaries_SE_MLE = []    #ML Engineer
salaries_SE_MDA = []    #Marketing Data Analyst
salaries_SE_MLS = []    #Machine Learning Scientist
salaries_SE_MLM = []    #Machine Learing Manager
salaries_SE_MLIE = []   #Machine Learning Infrastructure Engineer
salaries_SE_ML_E = []   #Machine learning Engineer
salaries_SE_LMLE = []   #Lead Machine Learning Engineer
salaries_SE_LDS = []    #Lead Data Scientist
salaries_SE_LDE = []    #Lead Data Engineer
salaries_SE_LDA = []    #Lead Data Analyst
salaries_SE_HOD = []    #Head of Data
salaries_SE_FDA = []    #Finance Data Analyst
salaries_SE_DoDS = []   #Director of Data Science
salaries_SE_DoDE = []   #Director of Data Engineering
salaries_SE_Ds = []     #Data Specialist
salaries_SE_DS = []     #Data Scientist
salaries_SE_DSM = []   #Data Sciene Manager
salaries_SE_DEM = []    #Data Engineering Manager
salaries_SE_DE = []     #Data engineering
salaries_SE_DAr = []    #Data Architect
salaries_SE_DAM = []    #Data Analytics Manager
salaries_SE_DAL = []    #Data Analytics Lead
salaries_SE_DAE = []    #Data Analytics Engineer
salaries_SE_DA = []     #Data Analyst
salaries_SE_CVE = []    #Computer Vision Engineer
salaries_SE_CDE = []    #Cloud Data Engineer
salaries_SE_BDE = []    #Big Data Engineer
salaries_SE_BDA = []    #Big Data Architect
salaries_SE_ADS = []    #Appied Data Scientist
salaries_SE_AE = []     #Analytics Engineer
salaries_SE_AIS = []    #AI Scientist
##salary for MI title
salaries_MI_RS = []     #MI Research Scientist
salaries_MI_PDDA = []   #Product Data Analyst
salaries_MI_PDS = []    #Principal Data Scientist
salaries_MI_PDA = []    #Principal Data Analyst
salaries_MI_NLPE = []   #NLP Engineer
salaries_MI_MLE = []    #ML Engineer
salaries_MI_MLS = []    #Machine Learning Scientist
salaries_MI_MLIE = []   #Machine Learning Infrastructure Engineer
salaries_MI_ML_E = []   #Machine Learning Engineer
salaries_MI_MLD = []    #Machine Learning Developer
salaries_MI_LDS = []    #Lead Data Scientist
salaries_MI_LDE = []    #Lead Data Engineer
salaries_MI_LDA = []    #Lead Data Analyst
salaries_MI_HDS = []    #Head of Data Science
salaries_MI_HOD = []    #Head of Data
salaries_MI_FDA = []    #Financial Data Analyst
salaries_MI_ETLD = []   #ETL Developer
salaries_MI_DS = []     #Data Scientist
salaries_MI_DSM = []    #Data Science Manager
salaries_MI_DSE = []    #Data Science Engineer
salaries_MI_DSC = []    #Data Science Consultant
salaries_MI_DEM = []    #Data Engineering Manager
salaries_MI_DE = []     #Data Engineer
salaries_MI_DAr = []    #Data Architect
salaries_MI_DAE = []    #Data Analytics Engineer
salaries_MI_DA = []     #Data Analyst
salaries_MI_CVSE = []   #Computer Vision Software Engineer
salaries_MI_CDE= []     #Cloud Data Engineer
salaries_MI_BA = []     #Business Data Analyst
salaries_MI_BDE = []    #Big Data Engineer
salaries_MI_BIDA = []   #BI Data Analyst
salaries_MI_AMLS = []   #Applied Machine Learning Scientist
salaries_MI_ADS = []    #Applied Data Scientist
salaries_MI_AIS = []    #AI Scientist
salaries_MI_3DCVR = []  #3D Computer Vision Researcher
##salary for EX title
salaries_EX_PDS = []    #Principal Data Scientist
salaries_EX_PDE = []    #Principal Data Engineer
salaries_EX_LDE = []    #Lead Data Engineer
salaries_EX_HOML = []   #Head of Machine Learning
salaries_EX_HDS = []    #Head of Data Science
salaries_EX_HOD = []    #Head of Data
salaries_EX_DoDS = []   #Director of Data Science
salaries_EX_DSC= []     #Data Science Consultant
salaries_EX_DEM = []    #Data Engineering Manager
salaries_EX_DE= []     #Data Engineer
salaries_EX_BIDA = []   #BI Data Analyst
salaries_EX_AE = []     #Analytics Engineer
##salary for EN
salaries_EN_RS= [] #Research Scientist
salaries_EN_MLE= [] #ML Engineer
salaries_EN_MLS= [] #Machine Learning Scientist
salaries_EN_ML_E= [] #Machine Learning Engineer
salaries_EN_MLD= [] #Machine Learning Developer
salaries_EN_FDA= [] #Financial Data Analyst
salaries_EN_DS= [] #Data Scientist
salaries_EN_DSC= [] #Data Science Consultant
salaries_EN_DE= [] #Data Engineer
salaries_EN_DAE= [] #Data Analytics Engineer
salaries_EN_DA= [] #Data Analyst
salaries_EN_CVSE= [] #Computer Vision Software Engineer
salaries_EN_CVE= [] #Computer Vision Engineer
salaries_EN_BA= [] #Business Data Analyst
salaries_EN_BDE= [] #Big Data Engineer
salaries_EN_BIDA= [] #BI Data Analyst
salaries_EN_AMLS = [] #Applied Machine Learning Scientist
salaries_EN_ADS = [] #Applied Data Scientist
salaries_EN_AIS = [] #AI Scientist
#MAX and MIN salary
minTemp_3DCVR = []
maxTemp_3DCVR= []
minTempAIS = []
maxTempAIS = []
minTempAE = []
maxTempAE = []
minTempADC = []
maxTempADC = []
minTempAMLS = []
maxTempAMLS = []
minTempBIDA = []
maxTempBIDA = []
minTempBDAr = []
maxTempBDAr = []
minTempBDE = []
maxTempBDE = []
minTempBDA = []
maxTempBDA = []
minTempCDE = []
maxTempCDE = []
minTempCVE = []
maxTempCVE = []
minTempCVSE = []
maxTempCVSE = []
minTempDA = []
maxTempDA = []
minTempDAE = []
maxTempDAE = []
minTempDAL = []
maxTempDAL = []
minTempDAM = []
maxTempDAM = []
minTempDAr = []
maxTempDAr = []
minTempDE = []
maxTempDE = []
minTempDEM = []
maxTempDEM = []
minTempDSC = []
maxTempDSC = []
minTempDSE = []
maxTempDSE = []
minTempDSM = []
maxTempDSM = []
minTempDS = []
maxTempDS = []
minTempDs = []
maxTempDs = []
minTempDoDE = []
maxTempDoDE = []
minTempDoDS = []
maxTempDoDS = []
minTempETLD = []
maxTempETLD = []
minTempFDA = []
maxTempFDA = []
minTempFLDA = []
maxTempFLDA = []
minTempHOD = []
maxTempHOD = []
minTempHODS = []
maxTempHODS = []
minTempHODL = []
maxTempHODL = []
minTempLDA = []
maxTempLDA = []
minTempLDE = []
maxTempLDE = []
minTempLDS = []
maxTempLDS = []
minTempLMLE = []
maxTempLMLE = []
minTempMLD = []
maxTempMLD = []
minTempML_E = []
maxTempML_E = []
minTempMLIE = []
maxTempMLIE = []
minTempMLM = []
maxTempMLM = []
minTempMLS = []
maxTempMLS = []
minTempMDA = []
maxTempMDA = []
minTempMLE = []
maxTempMLE = []
minTempPDA = []
maxTempPDA = []
minTempPDE = []
maxTempPDE = []
minTempPDS = []
maxTempPDS = []
minTempPDDA = []
maxTempPDDA = []
minTempRS = []
maxTempRS = []
minTempSDS = []
maxTempSDS = []
#Average salary for each ratio
salaries_0 = []
salaries_50 = []
salaries_100 = []
ratio = []
total_ratio = []
counter = 0
#Q6 and Q7
#2020
Salaries_RS_2020 = []
Salaries_PDDA_2020 = []
Salaries_PDS_2020 = []
Salaries_MLE_2020 = []
Salaries_MLS_2020 = []
Salaries_MLM_2020 = []
Salaries_MLIE_2020 = []
Salaries_ML_E_2020 = []
Salaries_LDS_2020 = []
Salaries_LDE_2020 = []
Salaries_LDA_2020 = []
Salaries_DoDS_2020 = []
Salaries_DS_2020 = []
Salaries_DSM_2020 = []
Salaries_DSC_2020 = []
Salaries_DEM_2020 = []
Salaries_DE_2020 = []
Salaries_DA_2020 = []
Salaries_CVE_2020 = []
Salaries_BDA_2020 = []
Salaries_BIDA_2020 = []
Salaries_BDE_2020 = []
Salaries_AIS_2020 = []
#2021
Salaries_SDS_2021 = []
Salaries_RS_2021 = []
Salaries_PDS_2021 = []
Salaries_PDA_2021 = []
Salaries_PDE_2021 = []
Salaries_MLE_2021 = []
Salaries_MDA_2021 = []
Salaries_MLS_2021 = []
Salaries_MLIE_2021 = []
Salaries_ML_E_2021 = []
Salaries_MLD_2021 = []
Salaries_LDS_2021 = []
Salaries_LDE_2021 = []
Salaries_LDA_2021 = []
Salaries_HoDS_2021 = []
Salaries_HOD_2021 = []
Salaries_FLDA_2021 = []
Salaries_FDA_2021 = []
Salaries_DoDS_2021 = []
Salaries_DoDE_2021 = []
Salaries_DSL_2021 = []
Salaries_DS_2021 = []
Salaries_DSM_2021 = []
Salaries_DSE_2021 = []
Salaries_DSC_2021 = []
Salaries_DEM_2021 = []
Salaries_DE_2021 = []
Salaries_DAr_2021 = []
Salaries_DAM_2021 = []
Salaries_DAE_2021 = []
Salaries_DA_2021 = []
Salaries_CVSE_2021 = []
Salaries_CVE_2021 = []
Salaries_CDE_2021 = []
Salaries_BDA_2021 = []
Salaries_BDE_2021 = []
Salaries_BDAr_2021 = []
Salaries_BIDA_2021 = []
Salaries_AMLS_2021 = []
Salaries_ADS_2021 = []
Salaries_AIS_2021 = []
Salaries_3DCVR_2021 = []
#2022
Salaries_RS_2022 = []
Salaries_PDS_2022 = []
Salaries_PDA_2022 = []
Salaries_NLPE_2022 = []
Salaries_MLE_2022 = []
Salaries_MLS_2022 = []
Salaries_MLIE_2022 = []
Salaries_ML_E_2022 = []
Salaries_LMLE_2022 = []
Salaries_LDE_2022 = []
Salaries_HoML_2022 = []
Salaries_HoDS_2022 = []
Salaries_FLDA_2022 = []
Salaries_ETLD_2022 = []
Salaries_DoDS_2022 = []
Salaries_DS_2022 = []
Salaries_DSM_2022 = []
Salaries_DSE_2022 = []
Salaries_DE_2022 = []
Salaries_DAr_2022 = []
Salaries_DAM_2022 = []
Salaries_DAL_2022 = []
Salaries_DAE_2022 = []
Salaries_DA_2022 = []
Salaries_CVSE_2022 = []
Salaries_CVE_2022 = []
Salaries_BDA_2022 = []
Salaries_AMLS_2022 = []
Salaries_AE_2022 = []
Salaries_AIS_2022 = []
##Question 1 import and print out the csv
with open('ds_salaries.csv', 'r',newline="") as csvfile:
    my_reader = csv.reader(csvfile, )
    for row in my_reader:
         print(row)

print("##################################################################")
##Question2 Calculate the average salary for each year
with open('ds_salaries.csv', 'r',newline="") as csvfile:
      my_reader = csv.reader(csvfile,)
      for row in my_reader:
         if row[1]=="2020":
          salaries2020.append(float(row[7]))
         elif row[1]=="2021":
          salaries2021.append(float(row[7]))
         elif row[1]=="2022":
          salaries2022.append(float(row[7]))
      AvgSalaries_2020 = sum(salaries2020)/len(salaries2020)
      AvgSalaries_2021 = sum(salaries2021)/len(salaries2021)
      AvgSalaries_2022 = sum(salaries2022)/len(salaries2022)
      print("2020Average Salary is :",AvgSalaries_2020)
      print("2021Average Salary is :",AvgSalaries_2021)
      print("2022Average Salary is :",AvgSalaries_2022)
print("###############################################################")


##Question3 compare the average salary for 3 years and find which year is the most, which year is lowest
a=salaries2020
b=salaries2021
c=salaries2022

if a>b>c:
 print("2020 has highest salary, 2022 lowest")
elif a>c>b:
 print("2020 has highest salary, 2021 lowest")
elif b>c>a:
 print("2021 has highest salary, 2020 lowest")
elif b>a>c:
 print("2021 has highest salary, 2022 lowest")
elif c>a>b:
 print("2022 has highest salary, 2021 lowest")
elif c>b>a:
 print("2022 has highest salary, 2020 lowest")
print("###################################################################")



##Question4 fine the average salary for each tile on different experience
with open('ds_salaries.csv', 'r',newline="") as csvfile:
      my_reader = csv.reader(csvfile,)
#SE
      for row in my_reader:
           if row[2]=="SE":
                if row[4]=="Staff Data Scientist":
                 salaries_SE_SDS.append(float(row[7]))
                elif row[4]=="Research Scientist":
                 salaries_SE_RS.append(float(row[7]))
                elif row[4]=="Principal Data Scientist":
                 salaries_SE_PDS.append(float(row[7]))
                elif row[4]=="Principal Data Engineer":
                 salaries_SE_PDE.append(float(row[7]))
                elif row[4]=="Principal Data Analyst":
                 salaries_SE_PDA.append(float(row[7]))
                elif row[4]=="ML Engineer":
                 salaries_SE_MLE.append(float(row[7]))
                elif row[4]=="Marketing Data Analyst":
                 salaries_SE_MDA.append(float(row[7]))
                elif row[4]=="Machine Learning Scientist":
                 salaries_SE_MLS.append(float(row[7]))
                elif row[4]=="Machine Learning Manager":
                 salaries_SE_MLM.append(float(row[7]))
                elif row[4]=="Machine Learning Infrastructure Engineer":
                 salaries_SE_MLIE.append(float(row[7]))
                elif row[4]=="Machine Learning Engineer":
                 salaries_SE_ML_E.append(float(row[7]))
                elif row[4]=="Lead Machine Learning Engineer":
                 salaries_SE_LMLE.append(float(row[7]))
                elif row[4]=="Lead Data Scientist" :
                 salaries_SE_LDS.append(float(row[7]))
                elif row[4]=="Lead Data Engineer":
                 salaries_SE_LDE.append(float(row[7]))
                elif row[4]=="Lead Data Analyst":
                 salaries_SE_LDA.append(float(row[7]))
                elif row[4]=="Head of Data":
                 salaries_SE_HOD.append(float(row[7]))
                elif row[4]=="Finance Data Analyst":
                 salaries_SE_FDA.append(float(row[7]))
                elif row[4]=="Director of Data Science":
                 salaries_SE_DoDS.append(float(row[7]))
                elif row[4]=="Director of Data Engineering":
                 salaries_SE_DoDE.append(float(row[7]))
                elif row[4]=="Data Specialist":
                 salaries_SE_Ds.append(float(row[7]))
                elif row[4]=="Data Scientist":
                 salaries_SE_DS.append(float(row[7]))
                elif row[4]=="Data Science Manager":  
                 salaries_SE_DSM.append(float(row[7]))
                elif row[4]=="Data Engineering Manager":
                 salaries_SE_DEM.append(float(row[7]))
                elif row[4]=="Data Engineer":
                 salaries_SE_DE.append(float(row[7]))
                elif row[4]=="Data Architect":
                 salaries_SE_DAr.append(float(row[7]))
                elif row[4]=="Data Analytics Manager":
                 salaries_SE_DAM.append(float(row[7]))
                elif row[4]=="Data Analytics Lead":
                 salaries_SE_DAL.append(float(row[7]))
                elif row[4]=="Data Analytics Engineer":
                 salaries_SE_DAE.append(float(row[7]))
                elif row[4]=="Data Analyst":
                 salaries_SE_DA.append(float(row[7]))
                elif row[4]=="Computer Vision Engineer":
                 salaries_SE_CVE.append(float(row[7]))
                elif row[4]=="Cloud Data Engineer":
                 salaries_SE_CDE.append(float(row[7]))
                elif row[4]=="Big Data Engineer":
                 salaries_SE_BDE.append(float(row[7]))
                elif row[4]=="Big Data Architect":
                 salaries_SE_BDA.append(float(row[7]))
                elif row[4]=="Applied Data Scientist":
                 salaries_SE_ADS.append(float(row[7]))
                elif row[4]=="Analytics Engineer":
                 salaries_SE_AE.append(float(row[7]))
                elif row[4]=="AI Scientist":
                 salaries_SE_AIS.append(float(row[7]))
#MI
with open('ds_salaries.csv', 'r',newline="") as csvfile:
      my_reader = csv.reader(csvfile,)

      for row in my_reader:
           if row[2]=="MI":                 
              if row[4]=="Research Scientist":
                salaries_MI_RS.append(float(row[7]))
              elif row[4]=="Product Data Analyst":
                salaries_MI_PDDA.append(float(row[7]))
              elif row[4]=="Principal Data Scientist":
                salaries_MI_PDS.append(float(row[7]))
              elif row[4]=="Principal Data Analyst":
                salaries_MI_PDA.append(float(row[7]))
              elif row[4]=="NLP Engineer":
                salaries_MI_NLPE.append(float(row[7]))              
              elif row[4]=="ML Engineer":
                salaries_MI_MLE.append(float(row[7]))
              elif row[4]=="Machine Learning Engineer":
                salaries_MI_ML_E.append(float(row[7]))
              elif row[4]=="Machine Learning Scientist":
                salaries_MI_MLS.append(float(row[7]))
              elif row[4]=="Machine Learning Infrastructure Engineer":
                salaries_MI_MLIE.append(float(row[7]))
              elif row[4]=="Machine Learning Developer":
                salaries_MI_MLD.append(float(row[7]))
              elif row[4]=="Lead Data Scientist" :
                salaries_MI_LDS.append(float(row[7]))
              elif row[4]=="Lead Data Engineer":
                salaries_MI_LDE.append(float(row[7]))
              elif row[4]=="Lead Data Analyst":
                salaries_MI_LDA.append(float(row[7]))
              elif row[4]=="Head of Data Science":
                salaries_MI_HDS.append(float(row[7]))
              elif row[4]=="Head of Data":
                salaries_MI_HOD.append(float(row[7]))
              elif row[4]=="Financial Data Analyst":
                salaries_MI_FDA.append(float(row[7]))
              elif row[4]=="ETL Developer":
                salaries_MI_ETLD.append(float(row[7]))
              elif row[4]=="Data Scientist":
                salaries_MI_DS.append(float(row[7]))
              elif row[4]=="Data Science Manager":  
                salaries_MI_DSM.append(float(row[7]))
              elif row[4]=="Data Engineer":
                salaries_MI_DE.append(float(row[7]))
              elif row[4]=="Data Architect":
                salaries_MI_DAr.append(float(row[7]))
              elif row[4]=="Data Analytics Engineer":
                salaries_MI_DAE.append(float(row[7]))
              elif row[4]=="Data Analyst":
                salaries_MI_DA.append(float(row[7]))
              elif row[4]=="Big Data Engineer":
                salaries_MI_BDE.append(float(row[7]))
              elif row[4]=="Applied Data Scientist":
                salaries_MI_ADS.append(float(row[7]))
              elif row[4]=="AI Scientist":
                salaries_MI_AIS.append(float(row[7]))
              elif row[4]=="Cloud Data Engineer":
                salaries_MI_CDE.append(float(row[7]))
              elif row[4]=="Data Engineering Manager":
                salaries_MI_DEM.append(float(row[7]))
              elif row[4]=="Data Science Engineer":
                salaries_MI_DSE.append(float(row[7]))
              elif row[4]=="Data Science Consultant":
                salaries_MI_DSC.append(float(row[7]))
              elif row[4]=="Computer Vision Software Engineer":
                salaries_MI_CVSE.append(float(row[7]))
              elif row[4]=="Business Data Analyst":
                salaries_MI_BA.append(float(row[7]))
              elif row[4]=="BI Data Analyst":
                salaries_MI_BIDA.append(float(row[7]))
              elif row[4]=="Applied Machine Learning Scientist":
                salaries_MI_AMLS.append(float(row[7]))
              elif row[4]=="3D Computer Vision Researcher":
                salaries_MI_3DCVR.append(float(row[7]))

#EX
with open('ds_salaries.csv', 'r',newline="") as csvfile:
      my_reader = csv.reader(csvfile,)

      for row in my_reader:
           if row[2]=="EX":
              if row[4]=="Principal Data Scientist":
                salaries_EX_PDS.append(float(row[7]))
              elif row[4]=="Principal Data Engineer":
                salaries_EX_PDE.append(float(row[7]))
              elif row[4]=="Lead Data Engineer":
                salaries_EX_LDE.append(float(row[7]))
              elif row[4]=="Head of Machine Learning":
                salaries_EX_HOML.append(float(row[7]))
              elif row[4]=="Head of Data Science":
                salaries_EX_HDS.append(float(row[7]))              
              elif row[4]=="Head of Data":
                salaries_EX_HOD.append(float(row[7]))
              elif row[4]=="Director of Data Science":
                salaries_EX_DoDS.append(float(row[7]))
              elif row[4]=="Data Science Consultant":
                salaries_EX_DSC.append(float(row[7]))
              elif row[4]=="Data Engineering Manager":
                salaries_EX_DEM.append(float(row[7]))
              elif row[4]=="Data Engineer":
                salaries_EX_DE.append(float(row[7]))
              elif row[4]=="BI Data Analyst" :
                salaries_EX_BIDA.append(float(row[7]))
              elif row[4]=="Analytics Engineer":
                salaries_EX_AE.append(float(row[7]))
#EN
with open('ds_salaries.csv', 'r',newline="") as csvfile:
      my_reader = csv.reader(csvfile,)

      for row in my_reader:
           if row[2]=="EN":                
              if row[4]=="Research Scientist":
                salaries_EN_RS.append(float(row[7]))
              elif row[4]=="ML Engineer":
                salaries_EN_MLE.append(float(row[7]))
              elif row[4]=="Machine Learning Scientist":
                salaries_EN_MLS.append(float(row[7]))
              elif row[4]=="Machine Learning Engineer":
                salaries_EN_ML_E.append(float(row[7]))
              elif row[4]=="Machine Learning Developer":
                salaries_EN_MLD.append(float(row[7]))
              elif row[4]=="Financial Data Analyst":
                salaries_EN_FDA.append(float(row[7]))
              elif row[4]=="Data Scientist":
                salaries_EN_DS.append(float(row[7]))
              elif row[4]=="Data Science Consultant":
                salaries_EN_DSC.append(float(row[7]))
              elif row[4]=="Data Engineer":
                salaries_EN_DE.append(float(row[7]))
              elif row[4]=="Data Analytics Engineer":
                salaries_EN_DAE.append(float(row[7]))
              elif row[4]=="Data Analyst":
                salaries_EN_DA.append(float(row[7]))
              elif row[4]=="Computer Vision Software Engineer":
                salaries_EN_CVSE.append(float(row[7]))
              elif row[4]=="Computer Vision Engineer":
                salaries_EN_CVE.append(float(row[7]))
              elif row[4]=="Business Data Analyst":
                salaries_EN_BA.append(float(row[7]))
              elif row[4]=="Big Data Engineer":
                salaries_EN_BDE.append(float(row[7]))
              elif row[4]=="BI Data Analyst" :
                salaries_EN_BIDA.append(float(row[7]))
              elif row[4]=="Applied Machine Learning Scientist":
                salaries_EN_AMLS.append(float(row[7]))
              elif row[4]=="Applied Data Scientist":
                salaries_EN_ADS.append(float(row[7]))
              elif row[4]=="AI Scientist":
                salaries_EN_AIS.append(float(row[7]))




                
#Average salary for SE                
      AvgSalaries_SE_SDS = sum(salaries_SE_SDS)/len(salaries_SE_SDS)
      print("The Average salary of SE Staff Data Scientist: ",AvgSalaries_SE_SDS)
      AvgSalaries_SE_RS = sum(salaries_SE_RS)/len(salaries_SE_RS)
      print("The Average salary of SE Research Scientist: ",AvgSalaries_SE_RS)
      AvgSalaries_SE_PDS = sum(salaries_SE_PDS)/len(salaries_SE_PDS)
      print("The Average salary of SE Principal Data Scientist: ",AvgSalaries_SE_PDS)
      AvgSalaries_SE_PDE = sum(salaries_SE_PDE)/len(salaries_SE_PDE)
      print("The Average salary of SE Principal Data Engineer: ",AvgSalaries_SE_PDE)
      AvgSalaries_SE_PDA = sum(salaries_SE_PDA)/len(salaries_SE_PDA)
      print("The Average salary of SE Principal Data Analyst: ",AvgSalaries_SE_PDA)
      AvgSalaries_SE_MLE = sum(salaries_SE_MLE)/len(salaries_SE_MLE)
      print("The Average salary of SE ML Engineer: ",AvgSalaries_SE_MLE)
      AvgSalaries_SE_MDA = sum(salaries_SE_MDA)/len(salaries_SE_MDA)
      print("The Average salary of SE Marketing Data Analyst: ",AvgSalaries_SE_MDA)
      AvgSalaries_SE_MLS = sum(salaries_SE_MLS)/len(salaries_SE_MLS)
      print("The Average salary of SE Machine Learning Scientist: ",AvgSalaries_SE_SDS)
      AvgSalaries_SE_MLM = sum(salaries_SE_MLM)/len(salaries_SE_MLM)
      print("The Average salary of SE Machine Learing Manager: ",AvgSalaries_SE_MLM)
      AvgSalaries_SE_MLIE = sum(salaries_SE_MLIE)/len(salaries_SE_MLIE)
      print("The Average salary of SE Machine Learning Infrastructure Engineer: ",AvgSalaries_SE_MLIE)
      AvgSalaries_SE_ML_E = sum(salaries_SE_ML_E)/len(salaries_SE_ML_E)
      print("The Average salary of SE Machine learning Engineer: ",AvgSalaries_SE_ML_E)
      AvgSalaries_SE_LMLE = sum(salaries_SE_LMLE)/len(salaries_SE_LMLE)
      print("The Average salary of SE Lead Machine Learning Engineer: ",AvgSalaries_SE_LMLE)      
      AvgSalaries_SE_LDS = sum(salaries_SE_LDS)/len(salaries_SE_LDS)
      print("The Average salary of SE Lead Data Scientist: ",AvgSalaries_SE_LDS)
      AvgSalaries_SE_LDE = sum(salaries_SE_LDE)/len(salaries_SE_LDE)
      print("The Average salary of SE Lead Data Engineer: ",AvgSalaries_SE_LDE)      
      AvgSalaries_SE_HOD = sum(salaries_SE_HOD)/len(salaries_SE_HOD)
      print("The Average salary of SE Head of Data: ",AvgSalaries_SE_HOD)
      AvgSalaries_SE_FDA = sum(salaries_SE_FDA)/len(salaries_SE_FDA)
      print("The Average salary of SE Finance Data Analyst: ",AvgSalaries_SE_FDA)
      AvgSalaries_SE_DoDS = sum(salaries_SE_DoDS)/len(salaries_SE_DoDS)
      print("The Average salary of SE Director of Data Science: ",AvgSalaries_SE_DoDS)
      AvgSalaries_SE_DoDE = sum(salaries_SE_DoDE)/len(salaries_SE_DoDE)
      print("The Average salary of SE Director of Data Engineeringt: ",AvgSalaries_SE_DoDE)
      AvgSalaries_SE_Ds = sum(salaries_SE_Ds)/len(salaries_SE_Ds)
      print("The Average salary of SE Data Specialist: ",AvgSalaries_SE_Ds)
      AvgSalaries_SE_DS = sum(salaries_SE_DS)/len(salaries_SE_DS)
      print("The Average salary of SE Data Scientist: ",AvgSalaries_SE_DS)
      AvgSalaries_SE_DSM = sum(salaries_SE_DSM)/len(salaries_SE_DSM)
      print("The Average salary of SE Data Sciene Manager: ",AvgSalaries_SE_DSM)
      AvgSalaries_SE_DEM = sum(salaries_SE_DEM)/len(salaries_SE_DEM)
      print("The Average salary of SE Data Engineering Manager: ",AvgSalaries_SE_DEM)
      AvgSalaries_SE_DE = sum(salaries_SE_DE)/len(salaries_SE_DE)
      print("The Average salary of SE Data engineering: ",AvgSalaries_SE_DE)
      AvgSalaries_SE_DAr = sum(salaries_SE_DAr)/len(salaries_SE_DAr)
      print("The Average salary of SE Data Architect: ",AvgSalaries_SE_DAr)
      AvgSalaries_SE_DAM = sum(salaries_SE_DAM)/len(salaries_SE_DAM)
      print("The Average salary of SE Data Analytics Manager: ",AvgSalaries_SE_DAM)
      AvgSalaries_SE_DAL = sum(salaries_SE_DAL)/len(salaries_SE_DAL)
      print("The Average salary of SE Data Analytics Lead: ",AvgSalaries_SE_DAL)
      AvgSalaries_SE_DAE = sum(salaries_SE_DAE)/len(salaries_SE_DAE)
      print("The Average salary of SE Data Analytics Engineer: ",AvgSalaries_SE_DAE)
      AvgSalaries_SE_DA = sum(salaries_SE_DA)/len(salaries_SE_DA)
      print("The Average salary of SE Data Analyst: ",AvgSalaries_SE_DA)
      AvgSalaries_SE_CVE = sum(salaries_SE_CVE)/len(salaries_SE_CVE)
      print("The Average salary of SE Computer Vision Engineer: ",AvgSalaries_SE_CVE)
      AvgSalaries_SE_CDE = sum(salaries_SE_CDE)/len(salaries_SE_CDE)
      print("The Average salary of SE Cloud Data Engineer: ",AvgSalaries_SE_CDE)
      AvgSalaries_SE_BDE = sum(salaries_SE_BDE)/len(salaries_SE_BDE)
      print("The Average salary of SE Big Data Engineer: ",AvgSalaries_SE_BDE)
      AvgSalaries_SE_BDA = sum(salaries_SE_BDA)/len(salaries_SE_BDA)
      print("The Average salary of SE Big Data Architect: ",AvgSalaries_SE_BDA)
      AvgSalaries_SE_ADS = sum(salaries_SE_ADS)/len(salaries_SE_ADS)
      print("The Average salary of SE Applied Data Scientist: ",AvgSalaries_SE_ADS)
      AvgSalaries_SE_AE = sum(salaries_SE_AE)/len(salaries_SE_AE)
      print("The Average salary of SE Analytics Engineer: ",AvgSalaries_SE_AE)
      AvgSalaries_SE_AIS = sum(salaries_SE_AIS)/len(salaries_SE_AIS)
      print("The Average salary of SE AI Scientist: ",AvgSalaries_SE_AIS)

print("#############################################################################")

#Average salary for MI
AvgSalaries_MI_RS = sum(salaries_MI_RS)/len(salaries_MI_RS)
print("The Average salary of MI Research Scientist: ",AvgSalaries_MI_RS)
AvgSalaries_MI_PDDA = sum(salaries_MI_PDDA)/len(salaries_MI_PDDA)
print("The Average salary of MI Product Data Analyst: ",AvgSalaries_MI_PDDA)
AvgSalaries_MI_PDS = sum(salaries_MI_PDS)/len(salaries_MI_PDS)
print("The Average salary of MI Principal Data Scientist: ",AvgSalaries_MI_PDS)
AvgSalaries_MI_PDA = sum(salaries_MI_PDA)/len(salaries_MI_PDA)
print("The Average salary of MI Principal Data Analyst: ",AvgSalaries_MI_PDA)
AvgSalaries_MI_NLPE = sum(salaries_MI_NLPE)/len(salaries_MI_NLPE)
print("The Average salary of MI NLP Engineer: ",AvgSalaries_MI_NLPE)
AvgSalaries_MI_MLE = sum(salaries_MI_MLE)/len(salaries_MI_MLE)
print("The Average salary of MI ML Engineer: ",AvgSalaries_MI_MLE)
AvgSalaries_MI_MLS = sum(salaries_MI_MLS)/len(salaries_MI_MLS)
print("The Average salary of MI Machiune Learning Scientist: ",AvgSalaries_MI_MLS)
AvgSalaries_MI_MLIE = sum(salaries_MI_MLIE)/len(salaries_MI_MLIE)
print("The Average salary of MI Machine Learning Infrastructure Engineer: ",AvgSalaries_MI_MLIE)
AvgSalaries_MI_ML_E = sum(salaries_MI_ML_E)/len(salaries_MI_ML_E)
print("The Average salary of MI Machine Learning Engineer: ",AvgSalaries_MI_ML_E)
AvgSalaries_MI_MLD = sum(salaries_MI_MLD)/len(salaries_MI_MLD)
print("The Average salary of MI Machine LEarning Developerr: ",AvgSalaries_MI_MLD)
AvgSalaries_MI_LDS = sum(salaries_MI_LDS)/len(salaries_MI_LDS)
print("The Average salary of MI Lead Data Scientist: ",AvgSalaries_MI_LDS)
AvgSalaries_MI_LDE = sum(salaries_MI_LDE)/len(salaries_MI_LDE)
print("The Average salary of MI Lead Data Engineer: ",AvgSalaries_MI_LDE)
AvgSalaries_MI_LDA = sum(salaries_MI_LDA)/len(salaries_MI_LDA)
print("The Average salary of MI Lead Data Analyst: ",AvgSalaries_MI_LDA)
AvgSalaries_MI_HDS = sum(salaries_MI_HDS)/len(salaries_MI_HDS)
print("The Average salary of MI Head of Data Science: ",AvgSalaries_MI_HDS)      
AvgSalaries_MI_HOD = sum(salaries_MI_HOD)/len(salaries_MI_HOD)
print("The Average salary of MI Head of Data: ",AvgSalaries_MI_HOD)
AvgSalaries_MI_FDA = sum(salaries_MI_FDA)/len(salaries_MI_FDA)
print("The Average salary of MI Financial Data Analyst: ",AvgSalaries_MI_FDA)
AvgSalaries_MI_ETLD = sum(salaries_MI_ETLD)/len(salaries_MI_ETLD)
print("The Average salary of MI ETL Developer: ",AvgSalaries_MI_ETLD)
AvgSalaries_MI_DS = sum(salaries_MI_DS)/len(salaries_MI_DS)
print("The Average salary of MI Data Scientist: ",AvgSalaries_MI_DS)
AvgSalaries_MI_DSM = sum(salaries_MI_DSM)/len(salaries_MI_DSM)
print("The Average salary of MI Data Science Manager: ",AvgSalaries_MI_DSM)
AvgSalaries_MI_DSE = sum(salaries_MI_DSE)/len(salaries_MI_DSE)
print("The Average salary of MI Data Science Engineer: ",AvgSalaries_MI_DSE)
AvgSalaries_MI_DSE = sum(salaries_MI_DSE)/len(salaries_MI_DSE)
print("The Average salary of MI Data Science Engineer: ",AvgSalaries_MI_DSE)
AvgSalaries_MI_DSC = sum(salaries_MI_DSC)/len(salaries_MI_DSC)
print("The Average salary of MI Data Science Consultant: ",AvgSalaries_MI_DSC)
AvgSalaries_MI_DEM = sum(salaries_MI_DEM)/len(salaries_MI_DEM)
print("The Average salary of MI Data Engineering Manager: ",AvgSalaries_MI_DEM)
AvgSalaries_MI_DE = sum(salaries_MI_DE)/len(salaries_MI_DE)
print("The Average salary of MI Data Engineer: ",AvgSalaries_MI_DE)
AvgSalaries_MI_DAr = sum(salaries_MI_DAr)/len(salaries_MI_DAr)
print("The Average salary of MI Data Architect: ",AvgSalaries_MI_DAr)
AvgSalaries_MI_DAE = sum(salaries_MI_DAE)/len(salaries_MI_DAE)
print("The Average salary of MI Data Analytics Engineer: ",AvgSalaries_MI_DAE)
AvgSalaries_MI_DA = sum(salaries_MI_DA)/len(salaries_MI_DA)
print("The Average salary of MI Data Analyst: ",AvgSalaries_MI_DA)
AvgSalaries_MI_CVSE = sum(salaries_MI_CVSE)/len(salaries_MI_CVSE)
print("The Average salary of MI Computer Vision Software Engineer: ",AvgSalaries_MI_CVSE)
AvgSalaries_MI_CDE = sum(salaries_MI_CDE)/len(salaries_MI_CDE)
print("The Average salary of MI Cloud Data Engineer: ",AvgSalaries_MI_CDE)
AvgSalaries_MI_BA = sum(salaries_MI_BA)/len(salaries_MI_BA)
print("The Average salary of MI Business Data Analyst: ",AvgSalaries_MI_BA)
AvgSalaries_MI_BDE = sum(salaries_MI_BDE)/len(salaries_MI_BDE)
print("The Average salary of MI Big Data Engineer: ",AvgSalaries_MI_BDE)
AvgSalaries_MI_BIDA = sum(salaries_MI_BIDA)/len(salaries_MI_BIDA)
print("The Average salary of MI BI Data Analyst: ",AvgSalaries_MI_BIDA)
AvgSalaries_MI_AMLS = sum(salaries_MI_AMLS)/len(salaries_MI_AMLS)
print("The Average salary of MI Applied Machine Learning Scientistr: ",AvgSalaries_MI_AMLS)
AvgSalaries_MI_ADS = sum(salaries_MI_ADS)/len(salaries_MI_ADS)
print("The Average salary of MI Applied Data Scientist: ",AvgSalaries_MI_ADS)
AvgSalaries_MI_AIS = sum(salaries_MI_AIS)/len(salaries_MI_AIS)
print("The Average salary of MI AI Scientist: ",AvgSalaries_MI_AIS)
AvgSalaries_MI_3DCVR = sum(salaries_MI_3DCVR)/len(salaries_MI_3DCVR)
print("The Average salary of MI 3D Computer Vision Researcher: ",AvgSalaries_MI_3DCVR)
print("#########################################################################################")
#Average salary for EX
AvgSalaries_EX_PDS = sum(salaries_EX_PDS)/len(salaries_EX_PDS)
print("The Average salary of EX Principal Data Scientist: ",AvgSalaries_EX_PDS)
AvgSalaries_EX_PDE = sum(salaries_EX_PDE)/len(salaries_EX_PDE)
print("The Average salary of EX Principal Data Engineer: ",AvgSalaries_EX_PDE)
AvgSalaries_EX_LDE = sum(salaries_EX_LDE)/len(salaries_EX_LDE)
print("The Average salary of EX Lead Data Engineer: ",AvgSalaries_EX_LDE)
AvgSalaries_EX_HOML = sum(salaries_EX_HOML)/len(salaries_EX_HOML)
print("The Average salary of EX Head of Machine Learning: ",AvgSalaries_EX_HOML)
AvgSalaries_EX_HDS = sum(salaries_EX_HDS)/len(salaries_EX_HDS)
print("The Average salary of EX Head of Data Science: ",AvgSalaries_EX_HDS)
AvgSalaries_EX_HOD = sum(salaries_EX_HOD)/len(salaries_EX_HOD)
print("The Average salary of EX Head of Data: ",AvgSalaries_EX_HOD)
AvgSalaries_EX_DoDS = sum(salaries_EX_DoDS)/len(salaries_EX_DoDS)
print("The Average salary of EX Director of Data Science: ",AvgSalaries_EX_DoDS)
AvgSalaries_EX_DSC = sum(salaries_EX_DSC)/len(salaries_EX_DSC)
print("The Average salary of EX Data Science Consultant: ",AvgSalaries_EX_DSC)
AvgSalaries_EX_DEM  = sum(salaries_EX_DEM )/len(salaries_EX_DEM )
print("The Average salary of EX Data Engineering Manager: ",AvgSalaries_EX_DEM )
AvgSalaries_EX_BIDA = sum(salaries_EX_BIDA)/len(salaries_EX_BIDA)
print("The Average salary of EX BI Data Analyst: ",AvgSalaries_EX_BIDA)
AvgSalaries_EX_AE = sum(salaries_EX_AE)/len(salaries_EX_AE)
print("The Average salary of EX Analytics Engineert: ",AvgSalaries_EX_AE)
print("#############################################################################################")
#Average salary for EN
AvgSalaries_EN_RS = sum(salaries_EN_RS)/len(salaries_EN_RS)
print("The Average salary of EN Research Scientist: ",AvgSalaries_EN_RS)
AvgSalaries_EN_MLE = sum(salaries_EN_MLE)/len(salaries_EN_MLE)
print("The Average salary of EN ML Engineer: ",AvgSalaries_EN_MLE)
AvgSalaries_EN_MLS = sum(salaries_EN_MLS)/len(salaries_EN_MLS)
print("The Average salary of EN Machine Learning Scientist: ",AvgSalaries_EN_MLS)
AvgSalaries_EN_ML_E = sum(salaries_EN_ML_E)/len(salaries_EN_ML_E)
print("The Average salary of EN Machine Learning Engineer: ",AvgSalaries_EN_ML_E)
AvgSalaries_EN_MLD = sum(salaries_EN_MLD)/len(salaries_EN_MLD)
print("The Average salary of EN Machine Learning Developer: ",AvgSalaries_EN_MLD)
AvgSalaries_EN_FDA = sum(salaries_EN_FDA)/len(salaries_EN_FDA)
print("The Average salary of EN Financial Data Analyst: ",AvgSalaries_EN_FDA)
AvgSalaries_EN_DS = sum(salaries_EN_DS)/len(salaries_EN_DS)
print("The Average salary of EN Data Scientist: ",AvgSalaries_EN_DS)
AvgSalaries_EN_DSC = sum(salaries_EN_DSC)/len(salaries_EN_DSC)
print("The Average salary of EN Data Science Consultant: ",AvgSalaries_EN_DSC)
AvgSalaries_EN_DE = sum(salaries_EN_DE)/len(salaries_EN_DE)
print("The Average salary of EN Data Engineer: ",AvgSalaries_EN_DE)
AvgSalaries_EN_DAE = sum(salaries_EN_DAE)/len(salaries_EN_DAE)
print("The Average salary of EN Data Analytics Engineer: ",AvgSalaries_EN_DAE)
AvgSalaries_EN_DA = sum(salaries_EN_DA)/len(salaries_EN_DA)
print("The Average salary of EN Data Analyst: ",AvgSalaries_EN_DA)
AvgSalaries_EN_CVSE = sum(salaries_EN_CVSE)/len(salaries_EN_CVSE)
print("The Average salary of EN Computer Vision Software Engineer: ",AvgSalaries_EN_CVSE)
AvgSalaries_EN_CVE = sum(salaries_EN_CVE)/len(salaries_EN_CVE)
print("The Average salary of EN Computer Vision Engineer: ",AvgSalaries_EN_CVE)
AvgSalaries_EN_BA = sum(salaries_EN_BA)/len(salaries_EN_BA)
print("The Average salary of EN Business Data Analyst: ",AvgSalaries_EN_BA)
AvgSalaries_EN_BDE = sum(salaries_EN_BDE)/len(salaries_EN_BDE)
print("The Average salary of EN Big Data Engineer: ",AvgSalaries_EN_BDE)
AvgSalaries_EN_BIDA = sum(salaries_EN_BIDA)/len(salaries_EN_BIDA)
print("The Average salary of EN BI Data Analyst: ",AvgSalaries_EN_BIDA)
AvgSalaries_EN_AMLS = sum(salaries_EN_AMLS)/len(salaries_EN_AMLS)
print("The Average salary of EN Applied Machine Learning Scientist: ",AvgSalaries_EN_AMLS)
AvgSalaries_EN_ADS = sum(salaries_EN_ADS)/len(salaries_EN_ADS)
print("The Average salary of EN Applied Data Scientist: ",AvgSalaries_EN_ADS)
AvgSalaries_EN_AIS = sum(salaries_EN_AIS)/len(salaries_EN_AIS)
print("The Average salary of EN AI Scientist: ",AvgSalaries_EN_AIS)
print("###########################################################################################")
#Question 5 find the man and min salary for each title
with open('ds_salaries.csv', 'r',newline="") as csvfile:
    my_reader = csv.reader(csvfile,)
    for row in my_reader:
         if row[4] =="3D Computer Vision Researcher":
          minTemp_3DCVR.append(float(row[7]))
          maxTemp_3DCVR.append(float(row[7]))
    print ("Min Salary of 3D Computer Vision Researcher is ",min(minTemp_3DCVR))
    print ("Max Salary of 3D Computer Vision Researcher is ",max(maxTemp_3DCVR))
with open('ds_salaries.csv', 'r',newline="") as csvfile:
    my_reader = csv.reader(csvfile,)
    for row in my_reader:
         if row[4] =="AI Scientist":
          minTempAIS.append(float(row[7]))
          maxTempAIS.append(float(row[7]))
    print ("Min salary of AI Scientist is",min(minTempAIS))
    print ("Max salary of AI Scientist is",max(maxTempAIS))
with open('ds_salaries.csv', 'r',newline="") as csvfile:
    my_reader = csv.reader(csvfile,)
    for row in my_reader:
         if row[4] =="Analytics Engineer":
          minTempAE.append(float(row[7]))
          maxTempAE.append(float(row[7]))
    print ("Min salary of Analytics Engineer is",min(minTempAE))
    print ("Max salary of Analytics Engineer is",max(maxTempAE))
with open('ds_salaries.csv', 'r',newline="") as csvfile:
    my_reader = csv.reader(csvfile,)
    for row in my_reader:
         if row[4] =="Applied Data Scientist":
          minTempADC.append(float(row[7]))
          maxTempADC.append(float(row[7]))
    print ("Min salary of Applied Data Scientist is",min(minTempADC))
    print ("Max salary of Applied Data Scientist is",max(maxTempADC))
with open('ds_salaries.csv', 'r',newline="") as csvfile:
    my_reader = csv.reader(csvfile,)
    for row in my_reader:
         if row[4] =="Applied Machine Learning Scientist":
          minTempAMLS.append(float(row[7]))
          maxTempAMLS.append(float(row[7]))
    print ("Min salary of Applied Machine Learning Scientist is",min(minTempAMLS))
    print ("Max salary of Applied Machine Learning Scientist is",max(maxTempAMLS))
with open('ds_salaries.csv', 'r',newline="") as csvfile:
    my_reader = csv.reader(csvfile,)
    for row in my_reader:
         if row[4] =="BI Data Analyst":
          minTempBIDA.append(float(row[7]))
          maxTempBIDA.append(float(row[7]))
    print ("Min salary of Applied Machine Learning Scientist is",min(minTempBIDA))
    print ("Max salary of Applied Machine Learning Scientist is",max(maxTempBIDA))
with open('ds_salaries.csv', 'r',newline="") as csvfile:
    my_reader = csv.reader(csvfile,)
    for row in my_reader:
         if row[4] =="Big Data Architect":
          minTempBDAr.append(float(row[7]))
          maxTempBDAr.append(float(row[7]))
    print ("Min salary of Big Data Architect is",min(minTempBDAr))
    print ("Max salary of Big Data Architect is",max(maxTempBDAr))
with open('ds_salaries.csv', 'r',newline="") as csvfile:
    my_reader = csv.reader(csvfile,)
    for row in my_reader:
         if row[4] =="Big Data Engineer":
          minTempBDE.append(float(row[7]))
          maxTempBDE.append(float(row[7]))
    print ("Min salary of Big Data Engineer is",min(minTempBDE))
    print ("Max salary of Big Data Engineer is",max(maxTempBDE))
with open('ds_salaries.csv', 'r',newline="") as csvfile:
    my_reader = csv.reader(csvfile,)
    for row in my_reader:
         if row[4] =="Business Data Analyst":
          minTempBDA.append(float(row[7]))
          maxTempBDA.append(float(row[7]))
    print ("Min salary of Business Data Analyst is",min(minTempBDA))
    print ("Max salary of Business Data Analyst is",max(maxTempBDA))
with open('ds_salaries.csv', 'r',newline="") as csvfile:
    my_reader = csv.reader(csvfile,)
    for row in my_reader:
         if row[4] =="Cloud Data Engineer":
          minTempCDE.append(float(row[7]))
          maxTempCDE.append(float(row[7]))
    print ("Min salary of Cloud Data Engineer is",min(minTempCDE))
    print ("Max salary of Cloud Data Engineer is",max(maxTempCDE))
with open('ds_salaries.csv', 'r',newline="") as csvfile:
    my_reader = csv.reader(csvfile,)
    for row in my_reader:
         if row[4] =="Computer Vision Engineer":
          minTempCVE.append(float(row[7]))
          maxTempCVE.append(float(row[7]))
    print ("Min salary of Computer Vision Engineer is",min(minTempCVE))
    print ("Max salary of Computer Vision Engineer is",max(maxTempCVE))
with open('ds_salaries.csv', 'r',newline="") as csvfile:
    my_reader = csv.reader(csvfile,)
    for row in my_reader:
         if row[4] =="Computer Vision Software Engineer":
          minTempCVSE.append(float(row[7]))
          maxTempCVSE.append(float(row[7]))
    print ("Min salary of Computer Vision Software Engineer is",min(minTempCVSE))
    print ("Max salary of Computer Vision Software Engineer is",max(maxTempCVSE))
with open('ds_salaries.csv', 'r',newline="") as csvfile:
    my_reader = csv.reader(csvfile,)
    for row in my_reader:
         if row[4] =="Data Analyst":
          minTempDA.append(float(row[7]))
          maxTempDA.append(float(row[7]))
    print ("Min salary of Data Analyst is",min(minTempDA))
    print ("Max salary of Data Analyst is",max(maxTempDA))
with open('ds_salaries.csv', 'r',newline="") as csvfile:
    my_reader = csv.reader(csvfile,)
    for row in my_reader:
         if row[4] =="Data Analytics Engineer":
          minTempDAE.append(float(row[7]))
          maxTempDAE.append(float(row[7]))
    print ("Min salary of Data Analytics Engineer is",min(minTempDAE))
    print ("Max salary of Data Analytics Engineer is",max(maxTempDAE))
with open('ds_salaries.csv', 'r',newline="") as csvfile:
    my_reader = csv.reader(csvfile,)
    for row in my_reader:
         if row[4] =="Data Analytics Lead":
          minTempDAL.append(float(row[7]))
          maxTempDAL.append(float(row[7]))
    print ("Min salary of Data Analytics Lead is",min(minTempDAL))
    print ("Max salary of Data Analytics Lead is",max(maxTempDAL))
with open('ds_salaries.csv', 'r',newline="") as csvfile:
    my_reader = csv.reader(csvfile,)
    for row in my_reader:
         if row[4] =="Data Analytics Manager":
          minTempDAM.append(float(row[7]))
          maxTempDAM.append(float(row[7]))
    print ("Min salary of Data Analytics Manager is",min(minTempDAM))
    print ("Max salary of Data Analytics Manager is",max(maxTempDAM))
with open('ds_salaries.csv', 'r',newline="") as csvfile:
    my_reader = csv.reader(csvfile,)
    for row in my_reader:
         if row[4] =="Data Architect":
          minTempDAr.append(float(row[7]))
          maxTempDAr.append(float(row[7]))
    print ("Min salary of Data Architect is",min(minTempDAr))
    print ("Max salary of Data Architectr is",max(maxTempDAr))
with open('ds_salaries.csv', 'r',newline="") as csvfile:
    my_reader = csv.reader(csvfile,)
    for row in my_reader:
         if row[4] =="Data Engineer":
          minTempDE.append(float(row[7]))
          maxTempDE.append(float(row[7]))
    print ("Min salary of Data Engineer is",min(minTempDE))
    print ("Max salary of Data Engineer is",max(maxTempDE))
with open('ds_salaries.csv', 'r',newline="") as csvfile:
    my_reader = csv.reader(csvfile,)
    for row in my_reader:
         if row[4] =="Data Engineering Manager":
          minTempDEM.append(float(row[7]))
          maxTempDEM.append(float(row[7]))
    print ("Min salary of Data Engineering Manager is",min(minTempDEM))
    print ("Max salary of Data Engineering Manager is",max(maxTempDEM))
with open('ds_salaries.csv', 'r',newline="") as csvfile:
    my_reader = csv.reader(csvfile,)
    for row in my_reader:
         if row[4] =="Data Science Consultant":
          minTempDSC.append(float(row[7]))
          maxTempDSC.append(float(row[7]))
    print ("Min salary of Data Science Consultant is",min(minTempDSC))
    print ("Max salary of Data Science Consultant is",max(maxTempDSC))
with open('ds_salaries.csv', 'r',newline="") as csvfile:
    my_reader = csv.reader(csvfile,)
    for row in my_reader:
         if row[4] =="Data Science Engineer":
          minTempDSE.append(float(row[7]))
          maxTempDSE.append(float(row[7]))
    print ("Min salary of Data Science Engineer is",min(minTempDSE))
    print ("Max salary of Data Science Engineer is",max(maxTempDSE))
with open('ds_salaries.csv', 'r',newline="") as csvfile:
    my_reader = csv.reader(csvfile,)
    for row in my_reader:
         if row[4] =="Data Science Manager":
          minTempDSM.append(float(row[7]))
          maxTempDSM.append(float(row[7]))
    print ("Min salary of Data Science Manager is",min(minTempDSM))
    print ("Max salary of Data Science Manager is",max(maxTempDSM))
with open('ds_salaries.csv', 'r',newline="") as csvfile:
    my_reader = csv.reader(csvfile,)
    for row in my_reader:
         if row[4] =="Data Scientist":
          minTempDS.append(float(row[7]))
          maxTempDS.append(float(row[7]))
    print ("Min salary of Data Scientist is",min(minTempDS))
    print ("Max salary of Data Scientist is",max(maxTempDS))
with open('ds_salaries.csv', 'r',newline="") as csvfile:
    my_reader = csv.reader(csvfile,)
    for row in my_reader:
         if row[4] =="Data Specialist":
          minTempDs.append(float(row[7]))
          maxTempDs.append(float(row[7]))
    print ("Min salary of Data Specialist is",min(minTempDs))
    print ("Max salary of Data Specialist is",max(maxTempDs))
with open('ds_salaries.csv', 'r',newline="") as csvfile:
    my_reader = csv.reader(csvfile,)
    for row in my_reader:
         if row[4] =="Director of Data Engineering":
          minTempDoDE.append(float(row[7]))
          maxTempDoDE.append(float(row[7]))
    print ("Min salary of Director of Data Engineering is",min(minTempDoDE))
    print ("Max salary of Director of Data Engineering is",max(maxTempDoDE))
with open('ds_salaries.csv', 'r',newline="") as csvfile:
    my_reader = csv.reader(csvfile,)
    for row in my_reader:
         if row[4] =="Director of Data Science":
          minTempDoDS.append(float(row[7]))
          maxTempDoDS.append(float(row[7]))
    print ("Min salary of Director of Data Science is",min(minTempDoDS))
    print ("Max salary of Director of Data Science is",max(maxTempDoDS))
with open('ds_salaries.csv', 'r',newline="") as csvfile:
    my_reader = csv.reader(csvfile,)
    for row in my_reader:
         if row[4] =="ETL Developer":
          minTempETLD.append(float(row[7]))
          maxTempETLD.append(float(row[7]))
    print ("Min salary of ETL Developer is",min(minTempETLD))
    print ("Max salary of ETL Developer is",max(maxTempETLD))
with open('ds_salaries.csv', 'r',newline="") as csvfile:
    my_reader = csv.reader(csvfile,)
    for row in my_reader:
         if row[4] =="Finance Data Analyst":
          minTempFDA.append(float(row[7]))
          maxTempFDA.append(float(row[7]))
    print ("Min salary of Finance Data Analyst is",min(minTempFDA))
    print ("Max salary of Finance Data Analyst is",max(maxTempFDA))
with open('ds_salaries.csv', 'r',newline="") as csvfile:
    my_reader = csv.reader(csvfile,)
    for row in my_reader:
         if row[4] =="Financial Data Analyst":
          minTempFLDA.append(float(row[7]))
          maxTempFLDA.append(float(row[7]))
    print ("Min salary of Financial Data Analyst is",min(minTempFLDA))
    print ("Max salary of Financial Data Analyst is",max(maxTempFLDA))
with open('ds_salaries.csv', 'r',newline="") as csvfile:
    my_reader = csv.reader(csvfile,)
    for row in my_reader:
         if row[4] =="Head of Data":
          minTempHOD.append(float(row[7]))
          maxTempHOD.append(float(row[7]))
    print ("Min salary of Head of Data is",min(minTempHOD))
    print ("Max salary of Head of Data is",max(maxTempHOD))
with open('ds_salaries.csv', 'r',newline="") as csvfile:
    my_reader = csv.reader(csvfile,)
    for row in my_reader:
         if row[4] =="Head of Data Science":
          minTempHODS.append(float(row[7]))
          maxTempHODS.append(float(row[7]))
    print ("Min salary of Head of Data Science is",min(minTempHODS))
    print ("Max salary of Head of Data Science is",max(maxTempHODS))
with open('ds_salaries.csv', 'r',newline="") as csvfile:
    my_reader = csv.reader(csvfile,)
    for row in my_reader:
         if row[4] =="Head of Machine Learning":
          minTempHODL.append(float(row[7]))
          maxTempHODL.append(float(row[7]))
    print ("Min salary of Head of Machine Learning is",min(minTempHODL))
    print ("Max salary of Head of Machine Learning is",max(maxTempHODL))
with open('ds_salaries.csv', 'r',newline="") as csvfile:
    my_reader = csv.reader(csvfile,)
    for row in my_reader:
         if row[4] =="Lead Data Analyst":
          minTempLDA.append(float(row[7]))
          maxTempLDA.append(float(row[7]))
    print ("Min salary of Lead Data Analyst is",min(minTempLDA))
    print ("Max salary of Lead Data Analyst is",max(maxTempLDA))
with open('ds_salaries.csv', 'r',newline="") as csvfile:
    my_reader = csv.reader(csvfile,)
    for row in my_reader:
         if row[4] =="Lead Data Engineer":
          minTempLDE.append(float(row[7]))
          maxTempLDE.append(float(row[7]))
    print ("Min salary of Lead Data Engineer is",min(minTempLDE))
    print ("Max salary of Lead Data Engineer is",max(maxTempLDE))
with open('ds_salaries.csv', 'r',newline="") as csvfile:
    my_reader = csv.reader(csvfile,)
    for row in my_reader:
         if row[4] =="Lead Data Scientist":
          minTempLDS.append(float(row[7]))
          maxTempLDS.append(float(row[7]))
    print ("Min salary of Lead Data Scientist is",min(minTempLDS))
    print ("Max salary of Lead Data Scientist is",max(maxTempLDS))
with open('ds_salaries.csv', 'r',newline="") as csvfile:
    my_reader = csv.reader(csvfile,)
    for row in my_reader:
         if row[4] =="Lead Machine Learning Engineer":
          minTempLMLE.append(float(row[7]))
          maxTempLMLE.append(float(row[7]))
    print ("Min salary of Lead Machine Learning Engineer is",min(minTempLMLE))
    print ("Max salary of Lead Machine Learning Engineer is",max(maxTempLMLE))
with open('ds_salaries.csv', 'r',newline="") as csvfile:
    my_reader = csv.reader(csvfile,)
    for row in my_reader:
         if row[4] =="Machine Learning Developer":
          minTempMLD.append(float(row[7]))
          maxTempMLD.append(float(row[7]))
    print ("Min salary of Machine Learning Developer is",min(minTempMLD))
    print ("Max salary of Machine Learning Developer is",max(maxTempMLD))
with open('ds_salaries.csv', 'r',newline="") as csvfile:
    my_reader = csv.reader(csvfile,)
    for row in my_reader:
         if row[4] =="Machine Learning Engineer":
          minTempML_E.append(float(row[7]))
          maxTempML_E.append(float(row[7]))
    print ("Min salary of Machine Learning Engineer is",min(minTempML_E))
    print ("Max salary of Machine Learning Engineer is",max(maxTempML_E))
with open('ds_salaries.csv', 'r',newline="") as csvfile:
    my_reader = csv.reader(csvfile,)
    for row in my_reader:
         if row[4] =="Machine Learning Infrastructure Engineer":
          minTempMLIE.append(float(row[7]))
          maxTempMLIE.append(float(row[7]))
    print ("Min salary of Machine Learning Infrastructure Engineer is",min(minTempMLIE))
    print ("Max salary of Machine Learning Infrastructure Engineer is",max(maxTempMLIE))
with open('ds_salaries.csv', 'r',newline="") as csvfile:
    my_reader = csv.reader(csvfile,)
    for row in my_reader:
         if row[4] =="Machine Learning Manager":
          minTempMLM.append(float(row[7]))
          maxTempMLM.append(float(row[7]))
    print ("Min salary of Machine Learning Manager is",min(minTempMLM))
    print ("Max salary of Machine Learning Manager is",max(maxTempMLM))
with open('ds_salaries.csv', 'r',newline="") as csvfile:
    my_reader = csv.reader(csvfile,)
    for row in my_reader:
         if row[4] =="Machine Learning Scientist":
          minTempMLS.append(float(row[7]))
          maxTempMLS.append(float(row[7]))
    print ("Min salary of Machine Learning Scientist is",min(minTempMLS))
    print ("Max salary of Machine Learning Scientist is",max(maxTempMLS))
with open('ds_salaries.csv', 'r',newline="") as csvfile:
    my_reader = csv.reader(csvfile,)
    for row in my_reader:
         if row[4] =="Marketing Data Analyst":
          minTempMDA.append(float(row[7]))
          maxTempMDA.append(float(row[7]))
    print ("Min salary of Marketing Data Analyst is",min(minTempMDA))
    print ("Max salary of Marketing Data Analyst is",max(maxTempMDA))
with open('ds_salaries.csv', 'r',newline="") as csvfile:
    my_reader = csv.reader(csvfile,)
    for row in my_reader:
         if row[4] =="ML Engineer":
          minTempMLE.append(float(row[7]))
          maxTempMLE.append(float(row[7]))
    print ("Min salary of ML Engineer is",min(minTempMLE))
    print ("Max salary of ML Engineer is",max(maxTempMLE))
with open('ds_salaries.csv', 'r',newline="") as csvfile:
    my_reader = csv.reader(csvfile,)
    for row in my_reader:
         if row[4] =="Principal Data Analyst":
          minTempPDA.append(float(row[7]))
          maxTempPDA.append(float(row[7]))
    print ("Min salary of Principal Data Analyst is",min(minTempPDA))
    print ("Max salary of Principal Data Analyst is",max(maxTempPDA))
with open('ds_salaries.csv', 'r',newline="") as csvfile:
    my_reader = csv.reader(csvfile,)
    for row in my_reader:
         if row[4] =="Principal Data Engineer":
          minTempPDE.append(float(row[7]))
          maxTempPDE.append(float(row[7]))
    print ("Min salary of Principal Data Engineer is",min(minTempPDE))
    print ("Max salary of Principal Data Engineer is",max(maxTempPDE))
with open('ds_salaries.csv', 'r',newline="") as csvfile:
    my_reader = csv.reader(csvfile,)
    for row in my_reader:
         if row[4] =="Principal Data Scientist":
          minTempPDS.append(float(row[7]))
          maxTempPDS.append(float(row[7]))
    print ("Min salary of Principal Data Scientist is",min(minTempPDS))
    print ("Max salary of Principal Data Scientist is",max(maxTempPDS))
with open('ds_salaries.csv', 'r',newline="") as csvfile:
    my_reader = csv.reader(csvfile,)
    for row in my_reader:
         if row[4] =="Product Data Analyst":
          minTempPDDA.append(float(row[7]))
          maxTempPDDA.append(float(row[7]))
    print ("Min salary of Product Data Analyst is",min(minTempPDDA))
    print ("Max salary of Product Data Analyst is",max(maxTempPDDA))
with open('ds_salaries.csv', 'r',newline="") as csvfile:
    my_reader = csv.reader(csvfile,)
    for row in my_reader:
         if row[4] =="Research Scientist":
          minTempRS.append(float(row[7]))
          maxTempRS.append(float(row[7]))
    print ("Min salary of Research Scientist is",min(minTempRS))
    print ("Max salary of Research Scientist is",max(maxTempRS))
with open('ds_salaries.csv', 'r',newline="") as csvfile:
    my_reader = csv.reader(csvfile,)
    for row in my_reader:
         if row[4] =="Staff Data Scientist":
          minTempSDS.append(float(row[7]))
          maxTempSDS.append(float(row[7]))
    print ("Min salary of Staff Data Scientist is",min(minTempSDS))
    print ("Max salary of Staff Data Scientist is",max(maxTempSDS))

print("###########################################################################################")
#Q6 and Q7 find average salary for each tiltle,each year and find which tile change the most, which change the least
with open('ds_salaries.csv', 'r',newline="") as csvfile:
      my_reader = list(csv.reader(csvfile,))
      for row in my_reader[1:]:
           if row[1]=="2020":                 
              if row[4]=="Research Scientist":
                Salaries_RS_2020.append(float(row[7]))
              elif row[4]=="Product Data Analyst":
                Salaries_PDDA_2020.append(float(row[7]))
              elif row[4]=="Principal Data Scientist":
                Salaries_PDS_2020.append(float(row[7]))                
              elif row[4]=="ML Engineer":
                Salaries_MLE_2020.append(float(row[7]))                
              elif row[4]=="Machine Learning Scientist":
                Salaries_MLS_2020.append(float(row[7])) 
              elif row[4]=="Machine Learning Manager":
                Salaries_MLM_2020.append(float(row[7]))
              elif row[4]=="Machine Learning Infrastructure Engineer":
                Salaries_MLIE_2020.append(float(row[7]))                
              elif row[4]=="Machine Learning Engineer":
                Salaries_ML_E_2020.append(float(row[7]))                
              elif row[4]=="Lead Data Scientist":
                Salaries_LDS_2020.append(float(row[7]))
              elif row[4]=="Lead Data Engineer":                  
                Salaries_LDE_2020.append(float(row[7]))                
              elif row[4]=="Lead Data Analyst":
                Salaries_LDA_2020.append(float(row[7]))                
              elif row[4]=="Director of Data Science":
                Salaries_DoDS_2020.append(float(row[7])) 
              elif row[4]=="Data Scientist":
                Salaries_DS_2020.append(float(row[7]))                
              elif row[4]=="Data Science Manager":
                Salaries_DSM_2020.append(float(row[7]))                
              elif row[4]=="Data Science Consultant":
                Salaries_DSC_2020.append(float(row[7]))              
              elif row[4]=="Data Engineering Manager":
                Salaries_DEM_2020.append(float(row[7]))           
              elif row[4]=="Data Engineer":
                Salaries_DE_2020.append(float(row[7])) 
              elif row[4]=="Data Analyst":
                Salaries_DA_2020.append(float(row[7]))
              elif row[4]=="Computer Vision Engineer":
                Salaries_CVE_2020.append(float(row[7]))
              elif row[4]=="Business Data Analyst":
                Salaries_BDA_2020.append(float(row[7]))
              elif row[4]=="Big Data Engineer":
                Salaries_BDE_2020.append(float(row[7]))
              elif row[4]=="BI Data Analyst":
                Salaries_BIDA_2020.append(float(row[7]))
              elif row[4]=="AI Scientist":
                Salaries_AIS_2020.append(float(row[7]))
           elif row[1]=="2021":
              if row[4]=="Staff Data Scientist":
                Salaries_RS_2021.append(float(row[7]))
              elif row[4]=="Research Scientist":
                Salaries_RS_2021.append(float(row[7]))
              elif row[4]=="Principal Data Scientist":
                Salaries_PDS_2021.append(float(row[7])) 
              elif row[4]=="Principal Data Analyst":
                Salaries_PDA_2021.append(float(row[7])) 
              elif row[4]=="ML Engineer":
                Salaries_MLE_2021.append(float(row[7]))
              elif row[4]=="Marketing Data Analyst":
                Salaries_MDA_2021.append(float(row[7]))
              elif row[4]=="Machine Learning Scientist":
                Salaries_MLS_2021.append(float(row[7])) 
              elif row[4]=="Machine Learning Infrastructure Engineer":
                Salaries_MLIE_2021.append(float(row[7])) 
              elif row[4]=="Machine Learning Engineer":
                Salaries_ML_E_2021.append(float(row[7])) 
              elif row[4]=="Machine Learning Developer":
                Salaries_MLD_2021.append(float(row[7])) 
              elif row[4]=="Lead Data Scientist":
                Salaries_LDS_2021.append(float(row[7]))
              elif row[4]=="Lead Data Engineer":                  
                Salaries_LDE_2021.append(float(row[7]))  
              elif row[4]=="Lead Data Analyst":
                Salaries_LDA_2021.append(float(row[7]))
              elif row[4]=="Head of Data Science":
                Salaries_HoDS_2021.append(float(row[7]))
              elif row[4]=="Head of Data":
                Salaries_HOD_2021.append(float(row[7]))
              elif row[4]=="Financial Data Analyst":
                Salaries_FLDA_2021.append(float(row[7]))
              elif row[4]=="Finance Data Analyst":
                Salaries_FDA_2021.append(float(row[7]))
              elif row[4]=="Director of Data Science":
                Salaries_DoDS_2021.append(float(row[7]))
              elif row[4]=="Director of Data Engineering":
                Salaries_DoDE_2021.append(float(row[7]))
              elif row[4]=="Data Specialist":
                Salaries_DSL_2021.append(float(row[7]))
              elif row[4]=="Data Scientist":
                Salaries_DS_2021.append(float(row[7])) 
              elif row[4]=="Data Science Manager":
                Salaries_DSM_2021.append(float(row[7])) 
              elif row[4]=="Data Science Engineer":
                Salaries_DSE_2021.append(float(row[7]))
              elif row[4]=="Data Science Consultant":
                Salaries_DSC_2021.append(float(row[7])) 
              elif row[4]=="Data Engineering Manager":
                Salaries_DEM_2021.append(float(row[7])) 
              elif row[4]=="Data Engineer":
                Salaries_DE_2021.append(float(row[7]))
              elif row[4]=="Data Architect":
                Salaries_DAr_2021.append(float(row[7]))
              elif row[4]=="Data Analytics Manager":
                Salaries_DAM_2021.append(float(row[7]))
              elif row[4]=="Data Analyst":
                Salaries_DA_2021.append(float(row[7]))
              elif row[4]=="Computer Vision Software Engineer":
                Salaries_CVSE_2021.append(float(row[7]))
              elif row[4]=="Computer Vision Engineer":
                Salaries_CVE_2021.append(float(row[7]))
              elif row[4]=="Cloud Data Engineer":
                Salaries_CDE_2021.append(float(row[7]))
              elif row[4]=="Business Data Analyst":
                Salaries_BDA_2021.append(float(row[7]))
              elif row[4]=="Big Data Engineer":
                Salaries_BDE_2021.append(float(row[7]))
              elif row[4]=="Big Data Architect":
                Salaries_BDAr_2021.append(float(row[7]))
              elif row[4]=="BI Data Analyst":
                Salaries_BIDA_2021.append(float(row[7]))
              elif row[4]=="Applied Machine Learning Scientist":
                Salaries_AMLS_2021.append(float(row[7]))
              elif row[4]=="Applied Data Scientist":
                Salaries_ADS_2021.append(float(row[7]))
              elif row[4]=="AI Scientist":
                Salaries_AIS_2021.append(float(row[7]))
              elif row[4]=="3D Computer Vision Researcher":
                Salaries_3DCVR_2021.append(float(row[7]))
              elif row[4]=="Data Analytics Engineer":
                Salaries_DAE_2021.append(float(row[7]))     
           elif row[1]=="2022":
               if row[4]=="Research Scientist":
                Salaries_RS_2022.append(float(row[7]))
               elif row[4]=="Principal Data Scientist":
                Salaries_PDS_2022.append(float(row[7])) 
               elif row[4]=="Principal Data Analyst":
                Salaries_PDA_2022.append(float(row[7]))
               elif row[4]=="NLP Engineer":
                Salaries_NLPE_2022.append(float(row[7]))
               elif row[4]=="ML Engineer":
                Salaries_MLE_2022.append(float(row[7]))
               elif row[4]=="Machine Learning Scientist":
                Salaries_MLS_2022.append(float(row[7]))
               elif row[4]=="Machine Learning Infrastructure Engineer":
                Salaries_MLIE_2022.append(float(row[7]))
               elif row[4]=="Machine Learning Engineer":
                Salaries_ML_E_2022.append(float(row[7]))
               elif row[4]=="Lead Machine Learning Engineer":
                Salaries_LMLE_2022.append(float(row[7]))
               elif row[4]=="Lead Data Engineer":                  
                Salaries_LDE_2022.append(float(row[7])) 
               elif row[4]=="Head of Machine Learning":                  
                Salaries_HoML_2022.append(float(row[7]))
               elif row[4]=="Head of Data Science":
                Salaries_HoDS_2022.append(float(row[7]))
               elif row[4]=="Financial Data Analyst":
                Salaries_FLDA_2022.append(float(row[7]))
               elif row[4]=="ETL Developer":
                Salaries_ETLD_2022.append(float(row[7]))
               elif row[4]=="Director of Data Science":
                Salaries_DoDS_2022.append(float(row[7]))
               elif row[4]=="Data Scientist":
                Salaries_DS_2022.append(float(row[7]))
               elif row[4]=="Data Science Manager":
                Salaries_DSM_2022.append(float(row[7]))
               elif row[4]=="Data Science Engineer":
                Salaries_DSE_2022.append(float(row[7]))
               elif row[4]=="Data Engineer":
                Salaries_DE_2022.append(float(row[7]))
               elif row[4]=="Data Architect":
                Salaries_DAr_2022.append(float(row[7]))
               elif row[4]=="Data Analytics Manager":
                Salaries_DAM_2022.append(float(row[7]))
               elif row[4]=="Data Analytics Lead":
                Salaries_DAL_2022.append(float(row[7]))
               elif row[4]=="Data Analytics Engineer":
                Salaries_DAE_2022.append(float(row[7]))
               elif row[4]=="Data Analyst":
                Salaries_DA_2022.append(float(row[7]))
               elif row[4]=="Computer Vision Software Engineer":
                Salaries_CVSE_2022.append(float(row[7]))
               elif row[4]=="Computer Vision Engineer":
                Salaries_CVE_2022.append(float(row[7]))
               elif row[4]=="Business Data Analyst":
                Salaries_BDA_2022.append(float(row[7]))
               elif row[4]=="Applied Machine Learning Scientist":
                Salaries_AMLS_2022.append(float(row[7]))
               elif row[4]=="Analytics Engineer":
                Salaries_AE_2022.append(float(row[7]))
               elif row[4]=="AI Scientist":
                Salaries_AIS_2022.append(float(row[7]))
               
      AvgRS_2020 = sum(Salaries_RS_2020)/len(Salaries_RS_2020)
      AvgRS_2021 = sum(Salaries_RS_2021)/len(Salaries_RS_2021)
      AvgRS_2022 = sum(Salaries_RS_2022)/len(Salaries_RS_2022)
      Change_RS = abs(AvgRS_2022 - AvgRS_2020)
       
      AvgPDA_2021 = sum(Salaries_PDA_2021)/len(Salaries_PDA_2021)
      AvgPDA_2022 = sum(Salaries_PDA_2022)/len(Salaries_PDA_2022)
      Change_PDA = abs(AvgPDA_2021-AvgPDA_2022)
      
      AvgPDS_2020 = sum(Salaries_PDS_2020)/len(Salaries_PDS_2020)
      AvgPDS_2021 = sum(Salaries_PDS_2021)/len(Salaries_PDS_2021)
      AvgPDS_2022 = sum(Salaries_PDS_2022)/len(Salaries_PDS_2022)
      Change_PDS = abs(AvgPDS_2020-AvgPDS_2021)
      
      AvgMLE_2020 = sum(Salaries_MLE_2020)/len(Salaries_MLE_2020)
      AvgMLE_2021 = sum(Salaries_MLE_2021)/len(Salaries_MLE_2021)
      AvgMLE_2022 = sum(Salaries_MLE_2022)/len(Salaries_MLE_2022)
      Change_MLE = abs(AvgMLE_2022-AvgMLE_2020)
        
      AvgMLS_2020 = sum(Salaries_MLS_2020)/len(Salaries_MLS_2020)
      AvgMLS_2021 = sum(Salaries_MLS_2021)/len(Salaries_MLS_2021)
      AvgMLS_2022 = sum(Salaries_MLS_2022)/len(Salaries_MLS_2022)
      Change_MLS = abs(AvgMLS_2022-AvgMLS_2020)
      
      AvgMLM_2020 = sum(Salaries_MLM_2020 )/len(Salaries_MLM_2020)
      
      AvgML_E_2020 = sum(Salaries_ML_E_2020)/len(Salaries_ML_E_2020)
      AvgML_E_2021 = sum(Salaries_ML_E_2021)/len(Salaries_ML_E_2021)
      AvgML_E_2022 = sum(Salaries_ML_E_2022)/len(Salaries_ML_E_2022)
      Change_ML_E = abs(AvgML_E_2022-AvgML_E_2021)
      
      AvgMLIE_2020 = sum(Salaries_MLIE_2020)/len(Salaries_MLIE_2020)
      AvgMLIE_2021 = sum(Salaries_MLIE_2021)/len(Salaries_MLIE_2021)
      AvgMLIE_2022 = sum(Salaries_MLIE_2022)/len(Salaries_MLIE_2022)
      Change_MLIE = abs(AvgMLIE_2021-AvgMLIE_2020)

      AvgLDE_2020 = sum(Salaries_LDE_2020)/len(Salaries_LDE_2020)
      AvgLDE_2021 = sum(Salaries_LDE_2021)/len(Salaries_LDE_2021)
      AvgLDE_2022 = sum(Salaries_LDE_2022)/len(Salaries_LDE_2022)
      Change_LDE = abs(AvgLDE_2021-AvgLDE_2020)
      
      AvgLDS_2020 = sum(Salaries_LDS_2020)/len(Salaries_LDS_2020)
      AvgLDS_2021 = sum(Salaries_LDS_2021)/len(Salaries_LDS_2021)
      Change_LDS = abs(AvgLDS_2021-AvgLDS_2020)

      
      AvgLDA_2020 = sum(Salaries_LDA_2020)/len(Salaries_LDA_2020)
      AvgLDA_2021 = sum(Salaries_LDA_2021)/len(Salaries_LDA_2021)
      Change_LDA = abs(AvgLDA_2021-AvgLDA_2020)
      
      
      AvgDoDS_2020 = sum(Salaries_DoDS_2020)/len(Salaries_DoDS_2020)
      AvgDoDS_2021 = sum(Salaries_DoDS_2021)/len(Salaries_DoDS_2021)
      AvgDoDS_2022 = sum(Salaries_DoDS_2022)/len(Salaries_DoDS_2022)
      Change_DoDS = abs(AvgDoDS_2021-AvgDoDS_2020)

      
      AvgDS_2020 = sum(Salaries_DS_2020)/len(Salaries_DS_2020)
      AvgDS_2021 = sum(Salaries_DS_2021)/len(Salaries_DS_2021)
      AvgDS_2022 = sum(Salaries_DS_2022)/len(Salaries_DS_2022)
      Change_DS = abs(AvgDS_2022-AvgDS_2021)

      
      AvgDSM_2020 = sum(Salaries_DSM_2020)/len(Salaries_DSM_2020)
      AvgDSM_2021 = sum(Salaries_DSM_2021)/len(Salaries_DSM_2021)
      AvgDSM_2022 = sum(Salaries_DSM_2022)/len(Salaries_DSM_2022)
      Change_DSM = abs(AvgDSM_2021-AvgDSM_2020)

      AvgDSC_2020 = sum(Salaries_DSC_2020)/len(Salaries_DSC_2020)
      AvgDSC_2021 = sum(Salaries_DSC_2021)/len(Salaries_DSC_2021)
      Change_DSC = abs(AvgDSC_2021-AvgDSC_2020)
      
      AvgDEM_2020 = sum(Salaries_DEM_2020 )/len(Salaries_DEM_2020)
      AvgDEM_2021 = sum(Salaries_DEM_2021 )/len(Salaries_DEM_2021)
      Change_DEM = abs(AvgDEM_2021-AvgDEM_2020)
      
      AvgDE_2020 = sum(Salaries_DE_2020)/len(Salaries_DE_2020)
      AvgDE_2021 = sum(Salaries_DE_2021)/len(Salaries_DE_2021)
      AvgDE_2022 = sum(Salaries_DE_2022)/len(Salaries_DE_2022)
      Change_DE = abs(AvgDE_2021-AvgDE_2022)
      
      AvgDA_2020 = sum(Salaries_DA_2020)/len(Salaries_DA_2020)
      AvgDA_2021 = sum(Salaries_DA_2021)/len(Salaries_DA_2021)
      AvgDA_2022 = sum(Salaries_DA_2022)/len(Salaries_DA_2022)
      Change_DA = abs(AvgDA_2020-AvgDA_2022)

      
      AvgCVE_2020 = sum(Salaries_CVE_2020)/len(Salaries_CVE_2020)
      AvgCVE_2021= sum(Salaries_CVE_2021)/len(Salaries_CVE_2021)
      AvgCVE_2022= sum(Salaries_CVE_2022)/len(Salaries_CVE_2022)
      Change_CVE = abs(AvgCVE_2021-AvgCVE_2022)
      
      AvgBDA_2020 = sum(Salaries_BDA_2020)/len(Salaries_BDA_2020)
      AvgBDA_2021 = sum(Salaries_BDA_2021)/len(Salaries_BDA_2021)
      AvgBDA_2022 = sum(Salaries_BDA_2022)/len(Salaries_BDA_2022)
      Change_BDA = abs(AvgBDA_2022-AvgBDA_2020)
      
      AvgBIDA_2020 = sum(Salaries_BIDA_2020)/len(Salaries_BIDA_2020)
      AvgBIDA_2021 = sum(Salaries_BIDA_2021)/len(Salaries_BIDA_2021)
      Change_BIDA = abs(AvgBIDA_2021-AvgBIDA_2020)
      
      AvgBDE_2020 = sum(Salaries_BDE_2020)/len(Salaries_BDE_2020)
      AvgBDE_2021 = sum(Salaries_BDE_2021)/len(Salaries_BDE_2021)
      Change_BDE = abs(AvgBDE_2021-AvgBDE_2020)
      
      AvgAIS_2020 = sum(Salaries_AIS_2020 )/len(Salaries_AIS_2020 )
      AvgAIS_2021 = sum(Salaries_AIS_2021 )/len(Salaries_AIS_2021)
      AvgAIS_2022 = sum(Salaries_AIS_2022 )/len(Salaries_AIS_2022)
      Change_AIS = abs(AvgAIS_2021-AvgAIS_2020)
      
      AvgHoDS_2021 = sum(Salaries_HoDS_2021)/len(Salaries_HoDS_2021)
      AvgHoDS_2022 = sum(Salaries_HoDS_2022)/len(Salaries_HoDS_2022)
      Change_HoDS = abs(AvgHoDS_2021-AvgHoDS_2022)

      AvgFLDA_2021 = sum(Salaries_FLDA_2021)/len(Salaries_FLDA_2021)
      AvgFLDA_2022 = sum(Salaries_FLDA_2022)/len(Salaries_FLDA_2022)
      Change_FLDA = abs(AvgFLDA_2021-AvgFLDA_2022)

      AvgDSE_2021 = sum(Salaries_DSE_2021)/len(Salaries_DSE_2021)
      AvgDSE_2022 = sum(Salaries_DSE_2022)/len(Salaries_DSE_2022)
      Change_DSE = abs(AvgDSE_2021-AvgDSE_2022)

      AvgDAr_2021 = sum(Salaries_DAr_2021)/len(Salaries_DAr_2021)
      AvgDAr_2022 = sum(Salaries_DAr_2022)/len(Salaries_DAr_2022)
      Change_DAr = abs(AvgDAr_2021-AvgDAr_2022)

      AvgDAM_2021 = sum(Salaries_DAM_2021)/len(Salaries_DAM_2021)
      AvgDAM_2022 = sum(Salaries_DAM_2022)/len(Salaries_DAM_2022)
      Change_DAM = abs(AvgDAM_2021-AvgDAM_2022)
      
      AvgDAE_2021 = sum(Salaries_DAE_2021)/len(Salaries_DAE_2021)
      AvgDAE_2022 = sum(Salaries_DAE_2022)/len(Salaries_DAE_2022)
      Change_DAE = abs(AvgDAE_2021-AvgDAE_2022)

      AvgCVSE_2021 = sum(Salaries_CVSE_2021)/len(Salaries_CVSE_2021)
      AvgCVSE_2022 = sum(Salaries_CVSE_2022)/len(Salaries_CVSE_2022)
      Change_CVSE = abs(AvgCVSE_2021-AvgCVSE_2022)      

      AvgAMLS_2021 = sum(Salaries_AMLS_2021)/len(Salaries_AMLS_2021)
      AvgAMLS_2022 = sum(Salaries_AMLS_2022)/len(Salaries_AMLS_2022)
      Change_AMLS = abs(AvgAMLS_2021-AvgAMLS_2022)
      
      AvgDAL_2022 = sum(Salaries_DAL_2022)/len(Salaries_DAL_2022)
      AvgPDDA_2020 = sum(Salaries_PDDA_2020)/len(Salaries_PDDA_2020)
      AvgMDA_2021 = sum(Salaries_MLE_2021)/len(Salaries_MDA_2021)
      AvgMLD_2021 = sum(Salaries_MLD_2021)/len(Salaries_MLD_2021)
      AvgHOD_2021 = sum(Salaries_HOD_2021)/len(Salaries_HOD_2021)
      AvgFDA_2021 = sum(Salaries_FDA_2021)/len(Salaries_FDA_2021)
      AvgDoDE_2021 = sum(Salaries_DoDE_2021)/len(Salaries_DoDE_2021)
      AvgDSL_2021 = sum(Salaries_DSL_2021)/len(Salaries_DSL_2021)
      AvgDAM_2021 = sum(Salaries_DAM_2021)/len(Salaries_DAM_2021)
      AvgCDE_2021 = sum(Salaries_CDE_2021)/len(Salaries_CDE_2021)
      AvgBDAr_2021 = sum(Salaries_BDAr_2021)/len(Salaries_BDAr_2021)
      AvgADS_2021 = sum(Salaries_ADS_2021)/len(Salaries_ADS_2021)
      Avg3DCVR_2021 = sum(Salaries_3DCVR_2021)/len(Salaries_3DCVR_2021)
      AvgNLPE_2022 = sum(Salaries_NLPE_2022)/len(Salaries_NLPE_2022)
      AvgLMLE_2022 = sum(Salaries_LMLE_2022)/len(Salaries_LMLE_2022)
      AvgHoML_2022 = sum(Salaries_HoML_2022)/len(Salaries_HoML_2022)
      AvgETLD_2022 = sum(Salaries_ETLD_2022)/len(Salaries_ETLD_2022)
      AvgAE_2022 = sum(Salaries_AE_2022)/len(Salaries_AE_2022)

      print("2020Average Salary  of Research Scientist is :",AvgRS_2020)
      print("2021Average Salary  of Research Scientist is :",AvgRS_2021)
      print("2022Average Salary  of Research Scientist is :",AvgRS_2022)
      print("The biggest change of Research Scientist is",Change_RS)
      print("")
      print("2020Average Salary  of Principal Data Scientist is :",AvgPDS_2020)
      print("2021Average Salary  of Principal Data Scientist is :",AvgPDS_2021)
      print("2022Average Salary  of Principal Data Scientist is :",AvgPDS_2022)
      print("The change of biggest of Principal Data Scientist is",Change_PDA)
      print("")
      print("2020Average Salary  of ML Engineer is :",AvgMLE_2020)
      print("2021Average Salary  of ML Engineer is :",AvgMLE_2021)
      print("2022Average Salary  of ML Engineer is :",AvgMLE_2022)
      print("The biggest change of ML Engineer is",Change_MLE)
      print("")
      print("2020Average Salary  of Machine Learning Scientist is :",AvgMLS_2020 )
      print("2021Average Salary  of Machine Learning Scientist is :",AvgMLS_2021 )
      print("2022Average Salary  of Machine Learning Scientist is :",AvgMLS_2022 )
      print("The biggest change of Machine Learning Scientist is",Change_MLS)
      print('')
      print("2020Average Salary  of Machine Learning Manager is :",AvgMLM_2020)
      print("")
      print("2020Average Salary  of Machine Learning Engineer is :",AvgML_E_2020)
      print("2021Average Salary  of Machine Learning Engineer is :",AvgML_E_2021)
      print("2022Average Salary  of Machine Learning Engineer is :",AvgML_E_2022)
      print("The biggest change of Machine Learning Engineer is",Change_ML_E)
      print("")
      print("2020Average Salary  of Machine Learning Infrastructure Engineer is :",AvgMLIE_2020)
      print("2020Average Salary  of Machine Learning Infrastructure Engineer is :",AvgMLIE_2021)
      print("2020Average Salary  of Machine Learning Infrastructure Engineer is :",AvgMLIE_2022)
      print("The biggest change of Machine Learning Infrastructure Engineer is",Change_MLIE)
      print("")
      print("2020Average Salary  of Lead Data Scientist is :",AvgLDS_2020)
      print("2020Average Salary  of Lead Data Scientist is :",AvgLDS_2021)
      print("The biggest change of Lead Data Scientist is",Change_LDS)
      print("")
      print("2020Average Salary  of Lead Data Engineer is :",AvgLDE_2020)
      print("2021Average Salary  of Lead Data Engineer is :",AvgLDE_2021)
      print("2022Average Salary  of Lead Data Engineer is :",AvgLDE_2022)
      print("The biggest change of Research Scientist is",Change_LDE)
      print("")
      print("2020Average Salary  of Research Scientist is :",AvgRS_2020)
      print("2021Average Salary  of Research Scientist is :",AvgRS_2021)
      print("2022Average Salary  of Research Scientist is :",AvgRS_2022)
      print("The biggest change of Research Scientist is",Change_RS)
      print("")
      print("2020Average Salary  of Principal Data Scientist is :",AvgPDS_2020)
      print("2021Average Salary  of Principal Data Scientist is :",AvgPDS_2021)
      print("2022Average Salary  of Principal Data Scientist is :",AvgPDS_2022)
      print("The change of biggest of Principal Data Scientist is",Change_PDA)
      print("")
      print("2020Average Salary  of ML Engineer is :",AvgMLE_2020)
      print("2021Average Salary  of ML Engineer is :",AvgMLE_2021)
      print("2022Average Salary  of ML Engineer is :",AvgMLE_2022)
      print("The biggest change of ML Engineer is",Change_MLE)
      print("")
      print("2020Average Salary  of Machine Learning Scientist is :",AvgMLS_2020 )
      print("2021Average Salary  of Machine Learning Scientist is :",AvgMLS_2021 )
      print("2022Average Salary  of Machine Learning Scientist is :",AvgMLS_2022 )
      print("The biggest change of Machine Learning Scientist is",Change_MLS)
      print('')
      print("2020Average Salary  of Machine Learning Manager is :",AvgMLM_2020)
      print("")
      print("2020Average Salary  of Machine Learning Engineer is :",AvgML_E_2020)
      print("2021Average Salary  of Machine Learning Engineer is :",AvgML_E_2021)
      print("2022Average Salary  of Machine Learning Engineer is :",AvgML_E_2022)
      print("The biggest change of Machine Learning Engineer is",Change_ML_E)
      print("")
      print("2020Average Salary  of Machine Learning Infrastructure Engineer is :",AvgMLIE_2020)
      print("2020Average Salary  of Machine Learning Infrastructure Engineer is :",AvgMLIE_2021)
      print("2020Average Salary  of Machine Learning Infrastructure Engineer is :",AvgMLIE_2022)
      print("The biggest change of Machine Learning Infrastructure Engineer is",Change_MLIE)
      print("")
      print("2020Average Salary  of Lead Data Scientist is :",AvgLDS_2020)
      print("2020Average Salary  of Lead Data Scientist is :",AvgLDS_2021)
      print("The biggest change of Lead Data Scientist is",Change_LDS)
      print("")
      print("2020Average Salary  of Lead Data Engineer is :",AvgLDE_2020)
      print("2021Average Salary  of Lead Data Engineer is :",AvgLDE_2021)
      print("2022Average Salary  of Lead Data Engineer is :",AvgLDE_2022)
      print("The biggest change of Research Scientist is",Change_LDE)
      print('')
      print("2020Average Salary  of Lead Data Analyst is :",AvgLDA_2020)
      print("2020Average Salary  of Lead Data Analyst is :",AvgLDA_2021)
      print("The biggest change of Lead Data Analyst is",Change_LDA)
      print('')
      print("2020Average Salary  of Director of Data Science is :",AvgDoDS_2020)
      print("2021Average Salary  of Director of Data Science is :",AvgDoDS_2021)
      print("2022Average Salary  of Director of Data Science is :",AvgDoDS_2022)
      print("The biggest change of Director of Data Science is",Change_DoDS)
      print("")
      print("2020Average Salary  of Data Scientist is :",AvgDS_2020)
      print("2021Average Salary  of Data Scientist is :",AvgDS_2021)
      print("2022Average Salary  of Data Scientist is :",AvgDS_2022)
      print("The biggest change of Data Scientist is",Change_DS)
      print("")
      print("2020Average Salary  of Data Science Manager is :",AvgDSM_2020)
      print("2021Average Salary  of Data Science Manager is :",AvgDSM_2021)
      print("2022Average Salary  of Data Science Manager is :",AvgDSM_2022)
      print("The biggest change of Data Science Manager is",Change_DSM)
      print("")
      print("2020Average Salary  of Data Science Consultant is :",AvgDSC_2020)
      print("2021Average Salary  of Data Science Consultant is :",AvgDSC_2021)
      print("The biggest change of Data Science Consultant is",Change_DSC)
      print("")
      print("2020Average Salary  of Data Engineering Manager is :",AvgDEM_2020)
      print("2021Average Salary  of Data Engineering Manager is :",AvgDEM_2021)
      print("The biggest change of Data Engineering Manager is",Change_DEM)
      print("")
      print("2020Average Salary  of Data Engineer is :",AvgDE_2020)
      print("2021Average Salary  of Data Engineer is :",AvgDE_2021)
      print("2022Average Salary  of Data Engineer is :",AvgDE_2022)
      print("The biggest change of Data Engineer is",Change_DE)
      print("")
      print("2020Average Salary  of Data Analyst is :",AvgDA_2020)
      print("2021Average Salary  of Data Analyst is :",AvgDA_2021)
      print("2022Average Salary  of Data Analyst is :",AvgDA_2022)
      print("The biggest change of Data Analyst is",Change_DA)
      print("")
      print("2020Average Salary  of Computer Vision Engineer is :",AvgCVE_2020)
      print("2021Average Salary  of Computer Vision Engineer is :",AvgCVE_2021)
      print("2022Average Salary  of Computer Vision Engineer is :",AvgCVE_2022)
      print("The biggest change of Computer Vision Engineer is",Change_CVE)
      print("")
      print("2020Average Salary  of Business Data Analyst is :",AvgBDA_2020)
      print("2021Average Salary  of Business Data Analyst is :",AvgBDA_2021)
      print("2022Average Salary  of Business Data Analyst is :",AvgBDA_2022)
      print("The biggest change of Business Data Analyst is",Change_BDA)
      print("")
      print("2020Average Salary  of BI Data Analyst is :",AvgBIDA_2020)
      print("2021Average Salary  of BI Data Analyst is :",AvgBIDA_2021)
      print("The biggest change of BI Data Analyst is",Change_BIDA)
      print("")
      print("2020Average Salary  of Big Data Engineer is :",AvgBDE_2020)
      print("2021Average Salary  of Big Data Engineer is :",AvgBDE_2021)
      print("The biggest change of Big Data Engineer is",Change_BDE)
      print("")
      print("2020Average Salary  of AI Scientist is :",AvgAIS_2020)
      print("2021Average Salary  of AI Scientist is :",AvgAIS_2021)
      print("2021Average Salary  of AI Scientist is :",AvgAIS_2022)
      print("The biggest change of AI Scientist is",Change_AIS)
      print("")
      print("2021Average Salary  of Principal Data Analyst is :",AvgPDA_2021)
      print("2022Average Salary  of Principal Data Analyst is :",AvgPDA_2022)
      print("The biggest change of Principal Data Analyst is",Change_PDA)
      print("")
      print("2021Average Salary  of Head of Data Science is :",AvgHoDS_2021)
      print("2022Average Salary  of Head of Data Science is :",AvgHoDS_2022)
      print("The biggest change of Head of Data Science is",Change_HoDS)
      print("")
      print("2021Average Salary  of Financial Data Analyst is :",AvgFLDA_2021)
      print("2022Average Salary  of Financial Data Analyst is :",AvgFLDA_2022)
      print("The biggest change of Financial Data Analyst is",Change_FLDA)
      print("")
      print("2021Average Salary  of Data Science Engineer is :",AvgDSE_2021)
      print("2022Average Salary  of Data Science Engineer is :",AvgDSE_2022)
      print("The biggest change of Data Science Engineer is",Change_DSE)
      print("")
      print("2021Average Salary  of Data Architect is :",AvgDAr_2021)
      print("2022Average Salary  of Data Architect is :",AvgDAr_2022)
      print("The biggest change of Data Architect is",Change_DAr)
      print("")
      print("2021Average Salary  of Data Analytics Manager is :",AvgDAM_2021)
      print("2022Average Salary  of Data Analytics Manager is :",AvgDAM_2022)
      print("The biggest change of Data Analytics Manager is",Change_DAM)
      print("")
      print("2021Average Salary  of Computer Vision Software Engineer is :",AvgCVSE_2021)
      print("2022Average Salary  of Computer Vision Software Engineer is :",AvgCVSE_2022)
      print("The biggest change of Computer Vision Software Engineer is",Change_CVSE)
      print("")
      print("2021Average Salary  of Applied Machine Learning Scientist is :",AvgAMLS_2021)
      print("2022Average Salary  of Applied Machine Learning Scientist is :",AvgAMLS_2022)
      print("The biggest change of Applied Machine Learning Scientist is",Change_AMLS)
      print("")
      print("2021Average Salary  of Data Analytics Engineer is :",AvgDAE_2021)
      print("2022Average Salary  of Data Analytics Engineer is :",AvgDAE_2022)
      print("The biggest change of Data Analytics Engineer is",Change_DAE)
      
      print("")      
      print("2022Average Salary  of Data Analytics Lead is :",AvgDAL_2022)
      print("2020Average Salary  of Product Data Analyst is :",AvgPDDA_2020)     
      print("2021Average Salary  of Marketing Data Analyst is :",AvgMDA_2021)
      print("2021Average Salary  of Machine Learning Developer is :",AvgMLD_2021)
      print("2021Average Salary  of Head of Data is :",AvgHOD_2021)
      print("2021Average Salary  of Finance Data Analyst is :",AvgFDA_2021)
      print("2021Average Salary  of Director of Data Engineering is :",AvgDoDS_2021)
      print("2021Average Salary  of Data Specialist is :",AvgDSL_2021)
      print("2021Average Salary  of Computer Cloud Data Engineer Engineer is :",AvgCDE_2021)
      print("2021Average Salary  of Big Data Architect is :",AvgBDAr_2021)
      print("2021Average Salary  of Applied Data Scientist is :",AvgADS_2021)
      print("2021Average Salary  of 3D Computer Vision Researcher is :",Avg3DCVR_2021)
      print("2021Average Salary  of NLP Engineer is :",AvgNLPE_2022)
      print("2021Average Salary  of Lead Machine Learning Engineer is :",AvgLMLE_2022)
      print("2021Average Salary  of Head of Machine Learning is :",AvgHoML_2022)
      print("2021Average Salary  of ETL Developer is :",AvgETLD_2022)
      print("2021Average Salary  of Analytics Engineer is :",AvgAE_2022)

      print("To get the biggest change and samllest change,I first exclude the titles thatappear only once, and then subtract the highest and lowest wages in the title to get the wage difference. The biggest change is:Financial Data Analyst,$350000,smallest change is: Data Analytics Manager:$818 ")


print("####################################################################################################")
#Question 8 find the avaerage for each remote ratio and find how types of remote ratio
with open('ds_salaries.csv', 'r',newline="") as csvfile:
      my_reader = list(csv.reader(csvfile,))
      for row in my_reader[1:]:
          if row[9]=="0":
              salaries_0.append(float(row[7]))
              ratio.append(float(row[9]))
          elif row[9]=="50":
              salaries_50.append(float(row[7]))
              ratio.append(float(row[9]))
          elif row[9]=="100":
              salaries_100.append(float(row[7]))
              ratio.append(float(row[9]))            
      AvgSalaries_0 = sum(salaries_0)/len(ratio)
      AvgSalaries_50 = sum(salaries_50)/len(ratio)
      AvgSalaries_100 = sum(salaries_100)/len(ratio)
      print("The average salary for 0 remote ratio is  :",AvgSalaries_0)
      print("The average salary for 50 remote ratio is  :",AvgSalaries_50)
      print("The average salary for 100 remote ratio is  :",AvgSalaries_100)

      for row in my_reader[1:]:
          total_ratio.append(float(row[9]))
      print("There are",len(set(total_ratio)),"entry/entries","They are:",set(total_ratio))
print("####################################################################################################")
#Question 9 find which country paid most, which paid least
import csv
salary_in_usd = []
country = []
with open('ds_salaries.csv', 'r',newline="") as csvfile:
      my_reader = list(csv.reader(csvfile,))
      for row in my_reader[1:]:
          salary_in_usd.append(float(row[7]))
          usd_index = salary_in_usd.index(max(salary_in_usd))
          usd_index_min = salary_in_usd.index(min(salary_in_usd))
          country.append(row[10])
          
      print("line:",usd_index_min,"Salary:",min(salary_in_usd),"Location:",country[usd_index_min])
      print("line:",usd_index,"Salary:",max(salary_in_usd),"Location:",country[usd_index])
print("###########################################################################")

#Question 10
print("Right now I don't want to change my resume. It semms like title abour data paid a fine salary")
